from __future__ import annotations
import json, os, sys, struct, threading, tkinter as tk
from tkinter import ttk, simpledialog, messagebox
from tvcgui.core.tk_host import tk_call
from tvcgui.core.paths import data_path, user_data_path

try:
    from tvcgui.platform.dolphin import rbytes, wbytes
except Exception:
    rbytes = None
    wbytes = None
SUPER_STRUCT_SIG = b"\x00\x00\x0C\x00\x00\x00\x23\x00"
SUPER_VERIFY_A   = b"\x00\x00\x04\x00\x00\x00\xFF\xFF\xFF\xFF"
SUPER_VERIFY_B   = b"\x3F\x80\x00\x00"
SUPER_VERIFY_LOOK = 0x120
_SUPER_STRUCT_DMG_OFF = 0x09

# Shinkuu / super-card experimental offsets from local base
_SUPER_EX_OFFSETS = {
    "ex03c": 0x03C,
    "ex060": 0x060,
    "ex090": 0x090,
    "ex094": 0x094,
    "ex09c": 0x09C,
    "ex0d4": 0x0D4,
    "ex0e4": 0x0E4,
}

# Temporary named super fields discovered from the probe pass.
# f32/u16 decides how the edit dialog writes the value.
_SUPER_FIELD_OFFSETS = {
    "super_hit_react":    (0x00A, "u16"),  # CONFIRMED: hit reaction
    "super_life":         (0x00E, "u16"),  # likely timer/lifetime
    "super_air_kb_y":     (0x038, "f32"),  # validated: super scale behaves like air KB Y
    "super_speed":        (0x090, "f32"),  # validated: speed on several supers
    "super_accel":        (0x094, "f32"),  # validated: secondary accel / release behavior
    "super_speed_2":      (0x09C, "f32"),  # validated: additional speed value
    "super_accel_b":      (0x0B0, "f32"),  # Ryu has 32 here; secondary motion/offset candidate
    "super_accel_c":      (0x0D4, "f32"),  # Ryu has 60 here; secondary motion/decel candidate
    # Legacy experimental fields from the first probe pass. Keep these for old rows,
    # but the display workbench uses the friendlier super_beam_* names below.
    "super_multihit_cap": (0x0D8, "u32"),  # old probe slot, not the Shinkuu hit-count field
    "super_radius":       (0x0E4, "f32"),  # CONFIRMED: super radius / hit radius

    # Shinkuu/Kikosho-style super beam card fields. Offsets are relative to the
    # real super-card base, e.g. Ryu Shinkuu at 0x908D0BD0.
    "super_hit_count":    (0x024, "u32"),  # 0x908D0BF4: number of hit emissions allowed
    "super_hit_interval": (0x028, "u32"),  # 0x908D0BF8: time spacing for each emitted hit
    "super_particle_fx":  (0x040, "u32"),  # 0x908D0C10: on-screen particle/effect id
    "super_beam_width":   (0x03C, "f32"),  # 0x908D0C0C: collision/beam width scale
    "super_hit_source":   (0x060, "u32"),  # 0x908D0C30: linked hit source/anchor, dangerous
    "super_spawn_bone":   (0x068, "u32"),  # 0x908D0C38: spawn bone/origin selector
    "super_lifetime":     (0x084, "u32"),  # 0x908D0C54: beam lifetime in frames/units
    "super_beam_visual":  (0x0E8, "u32"),  # 0x908D0CB8: render extent / visual shape

    # Final-hit card embedded after the main beam card. These are exposed on the
    # main super row for quick editing; they are not separate projectile rows.
    "super_final_damage":      (0x110, "u32"),
    "super_final_lifetime":    (0x114, "u32"),
    "super_final_particle_fx": (0x134, "u32"),
    "super_final_spawn_bone":  (0x154, "u32"),
}



# Compact 00/23 and 01/23 projectile-super cards.
# These are not Shinkuu/Kikosho beam cards; they are smaller hit/projectile
# records used by Volnutt Machine Gun Sweep, Casshan Brutal Ax, Tekkaman
# Voltekka chunks, and Morrigan Finishing Shower bullet tables.
PROJECTILE_SUPER_FMTS = {"projectile_super_card", "projectile_super_card_0123"}
_PROJECTILE_SUPER_FIELD_OFFSETS = {
    "ps_lifetime":      (0x008, "u16"),  # active/life window for this card
    "ps_hit_count":     (0x00C, "u16"),  # hit/emission count for this card
    "ps_mode":          (0x010, "u16"),  # card mode/style; still being farmed
    "ps_emit_count":    (0x018, "u16"),  # secondary emit/count field
    "ps_interval":      (0x01C, "u16"),  # interval/spacing when present
    "ps_offset_x":      (0x026, "f32"),  # spawn/velocity X-ish value
    "ps_offset_y":      (0x02A, "f32"),  # spawn/velocity Y-ish value
    "ps_scale":         (0x02E, "f32"),  # scale/radius-ish constant, often 1.0
    "ps_particle_fx":   (0x034, "u16"),  # particle/effect id
    "ps_projectile_id": (0x052, "u16"),  # projectile/object id/type slot
    "ps_spawn_bone":    (0x05C, "u16"),  # spawn bone/source selector when present
}

# ---------------------------------------------------------------------------
# Scan parameters
# ---------------------------------------------------------------------------
# The suffix the module search for in the template/template2 path.
# Full 12-byte signature:  00 00 XX YY  00 00 00 0C  <discriminator>
# Find _SUFFIX, then look 4 bytes back for the damage word.
_SUFFIX    = b"\x00\x00\x00\x0C"
SCAN_START = 0x90000000
SCAN_END   = 0x94000000
SCAN_BLOCK = 0x40000
PROJ_MAP_FILE = "projectilemap.json"
PROJ_IDS_FILE = "projectile_ids.json"

# ---------------------------------------------------------------------------
# Field offsets  -  corrected against MEM2 analysis notes
# ---------------------------------------------------------------------------
# All offsets are relative to the record base (the 00 00 XX YY word; that is,
# 4 bytes before _SUFFIX).
#
# Notes-confirmed corrections vs. previous version:
#   type     0x050 (u16) → 0x051 (u8)   [notes: u8 @ +0x51]
#   lifetime 0x05A (u16) → 0x05B (u8)   [notes: u8 @ +0x5B]
#   aerial_kb_x/y renamed kb_x/kb_y  -  the notes confirm these are general
#     knockback components, not aerial-specific.
#
# Validation-gate constants (checked before any field is read):
#   u16 @ +0x42 must == 10
#   u32 @ +0x04 must == 0x0000000C      (already implied by _SUFFIX hit)
#   f32 @ +0x84 must == 1.0
#   f32 @ +0x8C must == 100.0
#   u16 @ +0x6E must == 1024
#
# Discriminator at u32 @ +0x08:
#   0xFFFFFFFF          → "template"
#   0x00000000 or 0x01  → "template2"
#   anything else       → "script(0xNN)"  where NN = high byte of c[0]

FIELD_OFFSETS = {
    "radius":   0x02C,  # f32  -  hitbox radius (notes: consistently 1.0)
    "kb_x":     0x024,  # f32  -  knockback X component  (was aerial_kb_x)
    "kb_y":     0x028,  # f32  -  knockback Y component  (was aerial_kb_y)
    "c042":     0x042,  # u16  -  validation constant, always 10
    "type":     0x051,  # u8   -  type family: 3=Linear, 4=Physics  (CORRECTED +0x050→+0x051)
    "id":       0x052,  # u16  -  projectile type ID
    "lifetime": 0x05B,  # u8   -  active frames / lifetime           (CORRECTED +0x05A→+0x05B)
    "hb_size":  0x06E,  # u16  -  hitbox size (validation constant: 1024)
    "speed":    0x080,  # f32  -  speed scalar
    "accel":    0x084,  # f32  -  validation constant, always 1.0
    "hitbox":   0x08C,  # f32  -  hitbox radius (validation constant: 100.0)
    "arc":      0x090,  # f32  -  arc/gravity (Roll-specific)
    "arc2":     0x094,  # f32  -  arc modifier (Roll-specific)
    "vel2_x":   0x0D4,
    "vel2_y":   0x0D8,
    "vel2_s":   0x0DC,
    "u01": 0x10,
    "u02": 0x14,
    "u03": 0x18,
    "u04": 0x42,
    "u05": 0x48,
    "u06": 0x52,
    "u07": 0x5A,
    "u08": 0x68,
    "u09": 0x72,
}

# Validation-gate field addresses (relative to record base)
_VALID_C042    = 0x042   # u16 == 10
_VALID_ACCEL   = 0x084   # f32 == 1.0
_VALID_HITBOX  = 0x08C   # f32 == 100.0
_VALID_HBSIZE  = 0x06E   # u16 == 1024
_DISCRIMINATOR = 0x008   # u32: 0xFFFFFFFF=template, 0/1=template2

# ---------------------------------------------------------------------------
# Character / signature tables
# ---------------------------------------------------------------------------
_NAME_TO_KEY = {
    "Ryu": "RYU", "Chun-Li": "CHUN", "Jun the Swan": "JUN",
    "Ken the Eagle": "KEN", "Alex": "ALEX", "Batsu": "BATSU",
    "Frank West": "FRANK", "Volnutt": "VOLNUTT", "Morrigan": "MORRIGAN",
    "Roll": "ROLL", "Saki": "SAKI", "Viewtiful Joe": "VJOE",
    "Zero": "ZERO", "Casshan": "CASSHAN", "Doronjo": "DORONJO",
    "Ippatsuman": "IPPATSMAN", "Joe the Condor": "JOE",
    "Tekkaman": "TEKKAMAN", "Tekkaman Blade": "BLADE",
    "Yatterman-1": "YATTER1", "Yatterman-2": "YATTER2","Karas": "KARAS",
    "Gold Lightan": "LIGHTAN", "PTX-40A": "PTX",
}

# Fallback names for canonical Shinkuu/Kikosho-style beam cards when the
# owning slot is known but the per-hit damage value does not match that
# character's projectile map.  This is needed for supers like Morrigan's
# Finishing Shower, where the visible super is a multi-hit beam/barrage card
# with a small per-hit damage value that can collide with unrelated moves.
_SUPER_BEAM_DEFAULT_MOVE_BY_KEY = {
    "RYU": "Shinkuu Hadouken",
    "CHUN": "Kikosho",
    "MORRIGAN": "Finishing Shower",
    "VOLNUTT": "Machine Gun Sweep",
    "TEKKAMAN": "Voltekka",
    "CASSHAN": "Super Destruction Beam",
}

CHAR_SIGS = {
    "KEN": [b"\x00\x00\x00\x09"],
    "RYU": [b"\x00\x04\x01\x02"],
    
}

CHAR_SIG_OFFSETS = {
    "KEN": "pre",
    "RYU": "c",
    
}

_SIG_C_TO_KEYS:   dict[bytes, list[str]] = {}
_SIG_PRE_TO_KEYS: dict[bytes, list[str]] = {}

for _k, _sigs in CHAR_SIGS.items():
    _target = _SIG_PRE_TO_KEYS if CHAR_SIG_OFFSETS.get(_k) == "pre" else _SIG_C_TO_KEYS
    for _s in _sigs:
        _target.setdefault(_s, []).append(_k)

# ---------------------------------------------------------------------------
# Script opcode table
# ---------------------------------------------------------------------------
SCRIPT_OPCODES: dict[bytes, dict] = {
    b"\x05\x2B": {
        "fmt_name":   "script(0x052B)",
        "dmg_offset": 4,
    },
}

def _dmg_write_offset(fmt: str) -> int:
    if str(fmt or "") in PROJECTILE_SUPER_FMTS:
        return 4
    for info in SCRIPT_OPCODES.values():
        if info["fmt_name"] == fmt:
            return info["dmg_offset"]
    return 2  # default for template / template2

# ---------------------------------------------------------------------------
# chr_tbl param table  -  authoritative damage addresses for script-mode hits
#
# Each slot has a 16-byte parameter-entry table at a fixed offset from its
# chr_tbl_base.  The damage is a u32 big-endian at entry+0x00 (NOT u16 at +2).
#
#   chr_tbl_base + 0x25E0  →  u32 damage for the 2400-class entry (Spree/Attack)
#   chr_tbl_base + 0x2640  →  u32 damage for the 3200-class entry (Fall)
#
# Per-slot exact addresses (precomputed for fast lookup):
#   slot 0  chr_tbl 0x90896640  →  spree 0x90898C20  / fall 0x90898C80
#   slot 1  chr_tbl 0x908F1920  →  spree 0x908F3F00  / fall 0x908F3F60
#   slot 2  chr_tbl 0x909478E0  →  spree 0x90949EC0  / fall 0x90949F20
#   slot 3  chr_tbl 0x9099D9C0  →  spree 0x9099FFA0  / fall 0x909A0000
#
# Ownership: a hit address belongs to a slot when
#   chr_tbl_base <= hit_addr < chr_tbl_base + _CHR_TBL_SLOT_SIZE
# ---------------------------------------------------------------------------
_SCRIPT_DMG_OFFSETS: dict[int, int] = {
    2400: 0x25E0,   # u32 at entry start (Spree/Attack)
    3200: 0x2640,   # u32 at entry start (Fall)
}

_CHR_TBL_BASES = [
    0x90896640,   # slot 0
    0x908F1920,   # slot 1  (owns Frank West / Zombie addresses)
    0x909478E0,   # slot 2
    0x9099D9C0,   # slot 3
]
_CHR_TBL_SLOT_SIZE = 0x80000

# Frank West's character ID in the game's roster.
FRANK_CHAR_ID = 30   # 0x1E

# Fighter base addresses for each slot  -  char_id is read from base + 0x14.
# These are the same bases established in the slot/scanner work.
_FIGHTER_BASES = [
    0x9246B9C0,   # slot 0
    0x927EB9E0,   # slot 1
    0x92B6BA00,   # slot 2
    0x92EEBA20,   # slot 3
]
_CHAR_ID_OFF = 0x14   # offset within fighter base where char_id (u32 BE) lives

# chr_tbl_base → slot index, for mapping ownership back to fighter bases
_CHR_TBL_TO_SLOT = {
    0x90896640: 0,
    0x908F1920: 1,
    0x909478E0: 2,
    0x9099D9C0: 3,
}

_DYNAMIC_CHR_TBL_CACHE: list[int] | None = None

def _discover_chr_tbl_bases() -> list[int]:
    """Discover live chr_tbl bases from MEM2 instead of trusting old slot ranges.

    The projectile scanner originally used hard-coded chr_tbl bases from one
    session. That made same-damage projectile records from other slots show up
    under the currently selected character.  The frame-data scanner already
    proves the table by the literal chr_tbl/chr_act labels, so mirror that here.
    """
    global _DYNAMIC_CHR_TBL_CACHE
    if _DYNAMIC_CHR_TBL_CACHE:
        return list(_DYNAMIC_CHR_TBL_CACHE)
    if rbytes is None:
        return list(_CHR_TBL_BASES)

    found: list[int] = []
    label = b"chr_tbl\n"
    addr = SCAN_START
    while addr < SCAN_END:
        size = min(SCAN_BLOCK, SCAN_END - addr)
        try:
            data = rbytes(addr, size) or b""
        except Exception:
            data = b""
        pos = 0
        while data:
            idx = data.find(label, pos)
            if idx < 0:
                break
            base = addr + idx + 0x18
            try:
                chk = rbytes(base - 0x18, 0x2000) or b""
            except Exception:
                chk = b""
            if b"chr_act\n" in chk and base not in found:
                found.append(base)
            pos = idx + 1
        addr += size

    found.sort()
    if len(found) >= 4:
        _DYNAMIC_CHR_TBL_CACHE = found[:4]
    else:
        _DYNAMIC_CHR_TBL_CACHE = list(_CHR_TBL_BASES)
    return list(_DYNAMIC_CHR_TBL_CACHE)

def _current_chr_tbl_bases() -> list[int]:
    try:
        bases = _discover_chr_tbl_bases()
        return bases if bases else list(_CHR_TBL_BASES)
    except Exception:
        return list(_CHR_TBL_BASES)

def _projectile_key_from_char_id(cid: int | None) -> str | None:
    if cid is None:
        return None
    name_or_key = CHAR_ID_TO_KEY.get(cid)
    if not name_or_key:
        return None
    return _NAME_TO_KEY.get(str(name_or_key), str(name_or_key))

def _active_keys_from_lookup(lookup: dict) -> set[str]:
    keys: set[str] = set()
    try:
        for matches in lookup.values():
            for key, _mv in matches:
                keys.add(str(key))
    except Exception:
        pass
    return keys


def _read_slot_char_ids() -> dict[int, int]:
    """
    Read the live char_id for each slot from its fighter base + 0x14.
    Returns a dict of {chr_tbl_base: char_id}.
    Returns an empty dict if rbytes is unavailable.
    """
    result: dict[int, int] = {}
    if rbytes is None:
        return result
    bases = _current_chr_tbl_bases()
    for slot_idx, fighter_base in enumerate(_FIGHTER_BASES):
        chr_tbl_base = bases[slot_idx] if slot_idx < len(bases) else (_CHR_TBL_BASES[slot_idx] if slot_idx < len(_CHR_TBL_BASES) else None)
        if chr_tbl_base is None:
            continue
        try:
            b = rbytes(fighter_base + _CHAR_ID_OFF, 4)
            if b and len(b) == 4:
                cid = struct.unpack(">I", b)[0]
                result[int(chr_tbl_base)] = cid
        except Exception:
            pass
    return result


def _resolve_script_dmg_addr(hit_addr: int, dmg: int) -> int | None:
    """
    For a script-cluster hit, return the authoritative u32 param-table address
    for this damage value within the owning slot's chr_tbl region.
    Returns None if no mapping exists or no slot owns hit_addr.
    """
    off = _SCRIPT_DMG_OFFSETS.get(dmg)
    if off is None:
        return None
    base = _owning_chr_tbl(hit_addr)
    if base is None:
        return None
    return base + off


def _write_u32(addr: int, val: int) -> bool:
    """Write a big-endian u32  -  used for the zombie param-table entries."""
    if wbytes is None:
        return False
    try:
        return bool(wbytes(addr, struct.pack(">I", val)))
    except Exception as e:
        print(f"[proj_scanner] write u32 failed: {e}")
        return False

# ---------------------------------------------------------------------------
# Template format classification
#
# Uses the u32 discriminator at base+0x08, exactly as the notes specify:
#   0xFFFFFFFF          → "template"
#   0x00000000 / 0x01   → "template2"
#   anything else       → "script(0xNN)"
# ---------------------------------------------------------------------------
def _classify_discriminator(after4: bytes) -> str:
    """after4 = 4 bytes starting at base+0x08 (the 4 bytes after _SUFFIX)."""
    if len(after4) < 4:
        return "script(?)"
    disc = struct.unpack_from(">I", after4)[0]
    if disc == 0xFFFFFFFF:
        return "template"
    if disc in (0x00000000, 0x00000001):
        return "template2"
    return f"script(0x{(after4[0]):02X})"


# ---------------------------------------------------------------------------
# Validation gate for template / template2 records
#
# All five conditions from the notes must hold before any field is trusted.
# Returns True only if the record passes every check.
# ---------------------------------------------------------------------------
def _validate_template(data: bytes, base_off: int, relaxed: bool = False) -> bool:
    end = len(data)

    def u16(off: int) -> int | None:
        o = base_off + off
        if o + 2 > end:
            return None
        return struct.unpack_from(">H", data, o)[0]

    def u32(off: int) -> int | None:
        o = base_off + off
        if o + 4 > end:
            return None
        return struct.unpack_from(">I", data, o)[0]

    def f32(off: int) -> float | None:
        o = base_off + off
        if o + 4 > end:
            return None
        return struct.unpack_from(">f", data, o)[0]

    if not relaxed and u16(_VALID_C042) != 10:
        return False

    accel = f32(_VALID_ACCEL)
    if accel is None:
        return False
    if not relaxed:
        if not (abs(accel - 1.0) <= 1e-4 or abs(accel - 0.75) <= 1e-4):
            return False
    else:
        if not (-100.0 <= accel <= 100.0):
            return False

    hb = f32(_VALID_HITBOX)
    if hb is None:
        return False
    if not relaxed and abs(hb - 100.0) > 0.1:
        return False

    if not relaxed and u16(_VALID_HBSIZE) != 1024:
        return False

    disc = u32(_DISCRIMINATOR)
    if disc not in (0xFFFFFFFF, 0x00000000, 0x00000001):
        return False

    return True    
# ---------------------------------------------------------------------------
# Clustering helpers
#
# Groups validated template records by (proj_id, type_family) first, then by
# (damage, speed, kb_x, kb_y) to identify tiers/variants  -  exactly the
# workflow described in the notes.
# ---------------------------------------------------------------------------
def _cluster_key(h: dict) -> tuple:
    """Primary cluster key: (proj_id, type_family)."""
    try:
        pid = int(h.get("id", 0))
    except (ValueError, TypeError):
        pid = 0
    try:
        tf = int(h.get("type", 0))
    except (ValueError, TypeError):
        tf = 0
    return (pid, tf)


def _tier_key(h: dict) -> tuple:
    """Secondary cluster key within a family: (damage, speed_rounded, kb_x_rounded, kb_y_rounded)."""
    def _f(v, decimals=1):
        try:
            return round(float(v), decimals)
        except (ValueError, TypeError):
            return 0.0
    return (h.get("dmg", 0), _f(h.get("speed")), _f(h.get("kb_x")), _f(h.get("kb_y")))


def _annotate_clusters(hits: list[dict]) -> None:
    """
    Tag each template/template2 hit with a 'cluster' string of the form
    'ID:0xNNNN TF:N tier:M/T' so the UI can show grouping without a
    separate column explosion.

    Script/opcode hits are tagged 'script'  -  no cluster analysis.
    """
    from collections import defaultdict

    # Separate template hits from opcode hits
    tmpl_hits  = [h for h in hits if h.get("fmt") in ("template", "template2")]
    other_hits = [h for h in hits if h not in tmpl_hits]

    # Group by primary key
    families: dict[tuple, list[dict]] = defaultdict(list)
    for h in tmpl_hits:
        families[_cluster_key(h)].append(h)

    for ck, members in families.items():
        pid, tf = ck
        # Group by tier within the family
        tiers: dict[tuple, list[dict]] = defaultdict(list)
        for h in members:
            tiers[_tier_key(h)].append(h)
        total_tiers = len(tiers)
        tier_num    = 0
        for tk_, tier_members in tiers.items():
            tier_num += 1
            label = f"ID:0x{pid:04X} TF:{tf} tier:{tier_num}/{total_tiers}"
            for h in tier_members:
                h["cluster"] = label

    for h in other_hits:
        h["cluster"] = "script"


# ---------------------------------------------------------------------------
# Helper lookup builders
# ---------------------------------------------------------------------------
def _keys_for_block(c_word: bytes, pre_word: bytes) -> list[str]:
    keys = set()
    keys.update(_SIG_C_TO_KEYS.get(bytes(c_word), []))
    keys.update(_SIG_PRE_TO_KEYS.get(bytes(pre_word), []))
    return list(keys)


def _resource_path(name: str) -> str:
    """Find combat reference JSON in organized source and bundled data roots."""
    candidates = [
        data_path("combat", name),
        user_data_path("combat", name),
        os.path.join(os.getcwd(), "data", "combat", name),
        # Legacy fallbacks keep an older portable install readable.
        os.path.join(os.getcwd(), name),
        name,
    ]
    seen = set()
    for path in candidates:
        norm = os.path.normcase(os.path.abspath(path))
        if norm in seen:
            continue
        seen.add(norm)
        if os.path.exists(path):
            return path
    return data_path("combat", name)

def _load_map():
    try:
        with open(_resource_path(PROJ_MAP_FILE), encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[proj_scanner] {e}")
        return {}

def _load_ids():
    try:
        with open(_resource_path(PROJ_IDS_FILE), encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[proj_scanner] {e}")
        return {}
def _build_char_damage_map(proj_map):
    out = {}
    for key, moves in proj_map.items():
        dmg_map = {}
        for entry in moves:
            dmg = int(entry.get("dmg", 0))
            if dmg:
                dmg_map.setdefault(dmg, []).append(entry.get("move", "?"))
        out[key] = dmg_map
    return out


# Fill this with the live roster IDs.
# Example: FRANK is already known to be 30.
# Live roster char_id -> projectile-map key
CHAR_ID_TO_KEY = {
   1:  "Ken the Eagle",
    2:  "Casshan",
    3:  "Tekkaman",
    4:  "Polimar",
    5:  "Yatterman-1",
    6:  "Doronjo",
    7:  "Ippatsuman",
    8:  "Jun the Swan",
    10: "Karas",
    11: "Gold Lightan",
    12: "Ryu",
    13: "Chun-Li",
    14: "Batsu",
    15: "Morrigan",
    16: "Alex",
    17: "Viewtiful Joe",
    18: "Volnutt",
    19: "Roll",
    20: "Saki",
    21: "Soki",
    22: "PTX-40A",
    23: "Yami",
    26: "Tekkaman Blade",
    27: "Joe the Condor",
    28: "Yatterman-2",
    29: "Zero",
    30: "Frank West",
}
def _build_lookup(proj_map, active_keys):
    lookup = {}
    for key, moves in proj_map.items():
        if key not in active_keys:
            continue
        for entry in moves:
            dmg = int(entry.get("dmg", 0))
            if dmg:
                lookup.setdefault(dmg, []).append((key, entry.get("move", "?")))
    return lookup




# ---------------------------------------------------------------------------
# Memory helpers (live Dolphin reads)
# ---------------------------------------------------------------------------
def _read_u8(addr: int) -> str:
    if rbytes is None: return "?"
    try:
        b = rbytes(addr, 1)
        return str(b[0]) if b and len(b) == 1 else "?"
    except Exception:
        return "?"

def _read_u16(addr: int) -> str:
    if rbytes is None: return "?"
    try:
        b = rbytes(addr, 2)
        return str((b[0] << 8) | b[1]) if b and len(b) == 2 else "?"
    except Exception:
        return "?"

def _read_u32(addr: int) -> str:
    if rbytes is None: return "?"
    try:
        b = rbytes(addr, 4)
        return str(struct.unpack(">I", b)[0]) if b and len(b) == 4 else "?"
    except Exception:
        return "?"

def _read_u32_int(addr: int):
    """Internal u32 reader for scanner validation.

    The UI reader above returns text.  Validation needs an int; using the text
    reader made the canonical super-beam pass reject valid cards and fall back
    to shifted shadow rows.
    """
    if rbytes is None:
        return None
    try:
        b = rbytes(addr, 4)
        return struct.unpack(">I", b)[0] if b and len(b) == 4 else None
    except Exception:
        return None

def _read_u16_hex(addr: int) -> str:
    if rbytes is None: return "?"
    try:
        b = rbytes(addr, 2)
        if b and len(b) == 2:
            return f"0x{(b[0] << 8) | b[1]:04X}"
    except Exception:
        pass
    return "?"

def _read_f32(addr: int) -> str:
    if rbytes is None: return "?"
    try:
        b = rbytes(addr, 4)
        if b and len(b) == 4:
            return f"{struct.unpack('>f', b)[0]:.4f}"
    except Exception:
        pass
    return "?"

def _write_u16(addr: int, val: int) -> bool:
    if wbytes is None: return False
    try:
        return bool(wbytes(addr, bytes([(val >> 8) & 0xFF, val & 0xFF])))
    except Exception as e:
        print(f"[proj_scanner] write u16 failed: {e}")
        return False

def _write_f32(addr: int, val: float) -> bool:
    if wbytes is None: return False
    try:
        return bool(wbytes(addr, struct.pack(">f", val)))
    except Exception as e:
        print(f"[proj_scanner] write f32 failed: {e}")
        return False

def _write_dmg(addr: int, new_dmg: int, fmt: str) -> bool:
    return _write_u16(addr + _dmg_write_offset(fmt), new_dmg)


# ---------------------------------------------------------------------------
# Blank fields for opcode-scan hits
# ---------------------------------------------------------------------------
_OPCODE_HIT_FIELDS = {
    "radius": "?", "speed": "?", "accel": "?", "kb_x": "?", "kb_y": "?",
    "arc": "?", "arc2": "?", "hitbox": "?", "type": "?", "id": "?",
    "spawn_x": "?",
    "spawn_y": "?",
    "lifetime": "?", "hb_size": "?",
    "vel2_x": "?", "vel2_y": "?", "vel2_s": "?",
    "u01": "?", "u02": "?", "u03": "?",
    "u04": "?", "u05": "?", "u06": "?",
    "u07": "?", "u08": "?", "u09": "?",
    "cluster": "script",
    "ex03c": "?", "ex060": "?", "ex090": "?", "ex094": "?",
    "ex09c": "?", "ex0d4": "?", "ex0e4": "?",
    "super_speed": "?", "super_accel": "?",
    "super_speed_2": "?", "super_accel_b": "?", "super_accel_c": "?",
    "super_air_kb_y": "?", "super_multihit_cap": "?",
    "super_radius": "?", "super_hit_react": "?", "super_life": "?",
}


# ---------------------------------------------------------------------------
# Opcode-scan pass  (05 2B and any future SCRIPT_OPCODES entries)
# ---------------------------------------------------------------------------
def _scan_opcode_blocks(data: bytes, base_addr: int, hits: list, lookup: dict,
                        slot_char_ids: dict | None = None) -> None:
    frank_bases = {
        base for base, cid in (slot_char_ids or {}).items() if cid == FRANK_CHAR_ID
    }
    for sig, info in SCRIPT_OPCODES.items():
        fmt_name   = info["fmt_name"]
        dmg_offset = info["dmg_offset"]

        pos = 0
        while True:
            idx = data.find(sig, pos)
            if idx < 0:
                break
            pos = idx + 1

            if idx + dmg_offset + 2 > len(data):
                continue

            dmg = (data[idx + dmg_offset] << 8) | data[idx + dmg_offset + 1]
            if dmg < 2 or dmg > 20000:
                continue

            addr = base_addr + idx
            extra = {
                "preA":   _read_u8(addr - 2),
                "preB":   _read_u8(addr - 1),
                "opcode": _read_u16_hex(addr),
                "param1": _read_u16_hex(addr + 2),
                "param2": _read_u16_hex(addr + 4),
                "param3": _read_u16_hex(addr + 6),
                "f32_1":  _read_f32(addr + 8),
                "f32_2":  _read_f32(addr + 12),
                "f32_3":  _read_f32(addr + 16),
            }
            c_word = b""
            if addr >= base_addr + 4:
                c_word = data[idx - 4:idx]
            pre_word = data[idx - 8:idx - 4] if idx >= 8 else b""
            sig_keys = _keys_for_block(c_word, pre_word)

            base_hit = {
                "addr": addr,
                "dmg":  dmg,
                "fmt":  fmt_name,
                "dmg_write_addr": _resolve_script_dmg_addr(addr, dmg) or (addr + dmg_offset),
                **_OPCODE_HIT_FIELDS,
                **extra,
            }

            slot_key = _key_for_hit_addr(addr, slot_char_ids)

            if slot_key is not None:
                slot_matches = [(k, mv) for k, mv in lookup.get(dmg, []) if k == slot_key]
                if slot_matches:
                    for key, mv in slot_matches:
                        if (
                            key == "FRANK"
                            and "zombie" in str(mv).lower()
                            and _owning_chr_tbl(addr) in frank_bases
                            and not _is_frank_zombie_fall_label(mv)
                        ):
                            continue
                        hits.append({**base_hit, "key": key, "move": mv})
                    continue
                # If ownership is known and it is not the selected character, do
                # not fall back to damage-only lookup. This is what caused Chun/Jun
                # projectiles with Ryu-like damage to appear as Hadouken rows.
                if slot_key not in _active_keys_from_lookup(lookup):
                    continue

            if dmg in lookup:
                matches = lookup[dmg]

                if sig_keys:
                    sig_matches = [(k, mv) for k, mv in matches if k in sig_keys]
                    if sig_matches:
                        matches = sig_matches

                for key, mv in matches:
                    if (
                        key == "FRANK"
                        and "zombie" in str(mv).lower()
                        and _owning_chr_tbl(addr) in frank_bases
                        and not _is_frank_zombie_fall_label(mv)
                    ):
                        continue
                    hits.append({**base_hit, "key": key, "move": mv})
            elif sig_keys and dmg >= 1:
                for key in sig_keys:
                    hits.append({**base_hit, "key": key, "move": "Signature Match"})
            else:
                hits.append({**base_hit, "key": "?", "move": "Unknown"})

# ---------------------------------------------------------------------------
# Suffix-scan pass  (template / template2 / script(0xNN))
# ---------------------------------------------------------------------------
def _is_super_like_block(data: bytes, base_off: int) -> bool:
    """
    Permissive secondary filter for super/script-like blocks.
    This does NOT try to enforce the normal projectile template rules.
    """
    end = len(data)

    def u16(off: int) -> int | None:
        o = base_off + off
        if o + 2 > end:
            return None
        return struct.unpack_from(">H", data, o)[0]

    def u32(off: int) -> int | None:
        o = base_off + off
        if o + 4 > end:
            return None
        return struct.unpack_from(">I", data, o)[0]

    def f32(off: int) -> float | None:
        o = base_off + off
        if o + 4 > end:
            return None
        return struct.unpack_from(">f", data, o)[0]

    disc = u32(_DISCRIMINATOR)
    if disc is None:
        return False

    # Let the regular template/template2 path own those.
    if disc in (0xFFFFFFFF, 0x00000000, 0x00000001):
        return False

    dmg = u16(0x02)
    if dmg is None or not (500 <= dmg <= 20000):
        return False

    plausible = 0

    hb = f32(_VALID_HITBOX)
    if hb is not None and 0.0 <= hb <= 300.0:
        plausible += 1

    accel = f32(_VALID_ACCEL)
    if accel is not None and -10.0 <= accel <= 10.0:
        plausible += 1

    hb_size = u16(_VALID_HBSIZE)
    if hb_size is not None and 0 <= hb_size <= 4096:
        plausible += 1

    c042 = u16(_VALID_C042)
    if c042 is not None and 0 <= c042 <= 64:
        plausible += 1

    return plausible >= 2

def _scan_suffix_blocks(data: bytes, base_addr: int, hits: list,
                         lookup: dict, id_map: dict,
                         slot_char_ids: dict | None = None) -> None:
    frank_bases = {
        base for base, cid in (slot_char_ids or {}).items() if cid == FRANK_CHAR_ID
    }
    pos = 0
    while True:
        idx = data.find(_SUFFIX, pos)
        if idx < 0:
            break
        pos = idx + 1

        if idx < 4:
            continue

        c = data[idx - 4:idx]
        pre8 = data[idx - 8:idx - 4] if idx >= 8 else b""
        sig_keys = _keys_for_block(c, pre8)

        dmg = (c[2] << 8) | c[3]
        if not dmg:
            continue

        base_off = idx - 4
        a = base_addr + base_off

        after4 = data[idx + 4:idx + 8] if idx + 8 <= len(data) else b""
        fmt = _classify_discriminator(after4)

        is_template_ok = False
        is_super_ok = False

        if fmt in ("template", "template2"):
            slot_owned = _owning_chr_tbl(a) is not None
            if not slot_owned:
                ok = _validate_template(data, base_off)
                if not ok:
                    continue
            is_template_ok = True
        else:
            # New parallel permissive path for supers / script-like blocks
            if _owning_chr_tbl(a) is not None and _is_super_like_block(data, base_off):
                is_super_ok = True
                fmt = "super_like"
            else:
                continue


        if is_template_ok:
            fields = {
                "radius":   _read_f32(a + FIELD_OFFSETS["radius"]),
                "kb_x":     _read_f32(a + FIELD_OFFSETS["kb_x"]),
                "kb_y":     _read_f32(a + FIELD_OFFSETS["kb_y"]),
                "type":     _read_u8(a  + FIELD_OFFSETS["type"]),
                "id":       _read_u16(a + FIELD_OFFSETS["id"]),
                "lifetime": _read_u8(a  + FIELD_OFFSETS["lifetime"]),
                "hb_size":  _read_u16(a + FIELD_OFFSETS["hb_size"]),
                "speed":    _read_f32(a + FIELD_OFFSETS["speed"]),
                "accel":    _read_f32(a + FIELD_OFFSETS["accel"]),
                "hitbox":   _read_f32(a + FIELD_OFFSETS["hitbox"]),
                "arc":      _read_f32(a + FIELD_OFFSETS["arc"]),
                "arc2":     _read_f32(a + FIELD_OFFSETS["arc2"]),
                "vel2_x":   _read_f32(a + FIELD_OFFSETS["vel2_x"]),
                "vel2_y":   _read_f32(a + FIELD_OFFSETS["vel2_y"]),
                "vel2_s":   _read_f32(a + FIELD_OFFSETS["vel2_s"]),
                "u01":      _read_f32(a + FIELD_OFFSETS["u01"]),
                "u02":      _read_f32(a + FIELD_OFFSETS["u02"]),
                "u03":      _read_f32(a + FIELD_OFFSETS["u03"]),
                "u04":      _read_u16(a + FIELD_OFFSETS["u04"]),
                "u05":      _read_u16(a + FIELD_OFFSETS["u05"]),
                "u06":      _read_u16(a + FIELD_OFFSETS["u06"]),
                "u07":      _read_u16(a + FIELD_OFFSETS["u07"]),
                "u08":      _read_u16(a + FIELD_OFFSETS["u08"]),
                "u09":      _read_u16(a + FIELD_OFFSETS["u09"]),
                "preA": "?", "preB": "?",
                "opcode": "?", "param1": "?", "param2": "?", "param3": "?",
                "f32_1": "?", "f32_2": "?", "f32_3": "?",
                "cluster": "",
            }
        else:
            # super_like path: do not force all projectile fields to mean anything
            fields = {
                **_OPCODE_HIT_FIELDS,
                "speed":  _read_f32(a + FIELD_OFFSETS["speed"]),
                "accel":  _read_f32(a + FIELD_OFFSETS["accel"]),
                "hitbox": _read_f32(a + FIELD_OFFSETS["hitbox"]),
                "type":   _read_u8(a + FIELD_OFFSETS["type"]),
                "id":     _read_u16(a + FIELD_OFFSETS["id"]),
                "cluster": "super_like",
            }

        slot_key = _key_for_hit_addr(a, slot_char_ids)

        if slot_key is not None:
            slot_matches = [(k, mv) for k, mv in lookup.get(dmg, []) if k == slot_key]
            if slot_matches:
                matches = slot_matches

                if len({k for k, _ in matches}) > 1:
                    proj_id = fields.get("id")
                    try:
                        pid_int = int(proj_id)
                    except (TypeError, ValueError):
                        pid_int = None
                    if pid_int is not None:
                        id_matches = [
                            (k, mv) for k, mv in matches
                            if id_map.get(k, {}).get(mv) == pid_int
                        ]
                        if id_matches:
                            matches = id_matches

                for key, mv in matches:
                    if (
                        key == "FRANK"
                        and "zombie" in str(mv).lower()
                        and _owning_chr_tbl(a) in frank_bases
                        and not _is_frank_zombie_fall_label(mv)
                    ):
                        continue
                    hits.append({
                        "addr": a,
                        "key": key,
                        "move": mv,
                        "dmg": dmg,
                        "fmt": fmt,
                        "dmg_write_addr": _resolve_script_dmg_addr(a, dmg) or (a + 2),
                        **fields
                    })
                continue
            active_keys = _active_keys_from_lookup(lookup)
            if active_keys and slot_key not in active_keys:
                continue

        is_slot_owned = _owning_chr_tbl(a) is not None
        ok = _validate_template(data, base_off, relaxed=is_slot_owned)
        if dmg in lookup:
            matches = lookup[dmg]

            if sig_keys:
                sig_matches = [(k, mv) for k, mv in matches if k in sig_keys]
                if sig_matches:
                    matches = sig_matches

            if len({k for k, _ in matches}) > 1:
                proj_id = fields.get("id")
                try:
                    pid_int = int(proj_id)
                except (TypeError, ValueError):
                    pid_int = None
                if pid_int is not None:
                    id_matches = [
                        (k, mv) for k, mv in matches
                        if id_map.get(k, {}).get(mv) == pid_int
                    ]
                    if id_matches:
                        matches = id_matches

            for key, mv in matches:
                if (
                    key == "FRANK"
                    and "zombie" in str(mv).lower()
                    and _owning_chr_tbl(a) in frank_bases
                    and not _is_frank_zombie_fall_label(mv)
                ):
                    continue
                hits.append({
                    "addr": a,
                    "key": key,
                    "move": mv,
                    "dmg": dmg,
                    "fmt": fmt,
                    "dmg_write_addr": _resolve_script_dmg_addr(a, dmg) or (a + 2),
                    **fields
                })

        elif sig_keys and dmg >= 1:
            for key in sig_keys:
                hits.append({
                    "addr": a,
                    "key": key,
                    "move": "Signature Match",
                    "dmg": dmg,
                    "fmt": fmt,
                    "dmg_write_addr": _resolve_script_dmg_addr(a, dmg) or (a + 2),
                    **fields
                })

        elif dmg >= 500:
            hits.append({
                "addr": a,
                "key": "?",
                "move": "Unknown",
                "dmg": dmg,
                "fmt": fmt,
                "dmg_write_addr": _resolve_script_dmg_addr(a, dmg) or (a + 2),
                **fields
            })
# ---------------------------------------------------------------------------
# Zombie canonical block scanner
#
# The authoritative spawn-like signature for Zombie Spree/Attack/Fall is:
#   2C 11 02 3F  (block start marker)
#   followed within 0x40 bytes by:
#   04 01 02 3F 00 00 00 XX  (where XX is the variant byte)
#
# Only variants 0x36–0x3B are valid Zombie spawn variants per the notes.
# Anything outside this range is noise from other characters' scripts.
#
# Deduplication: one row per (chr_tbl_base, variant) across the full scan.
# ---------------------------------------------------------------------------
_ZOMBIE_BLOCK_SIG  = b"\x2C\x11\x02\x3F"
_ZOMBIE_INNER_SIG  = b"\x04\x01\x02\x3F\x00\x00\x00"
_ZOMBIE_INNER_LOOK = 0x40
_ZOMBIE_VARIANT_MIN = 0x36
_ZOMBIE_VARIANT_MAX = 0x3B

_ZOMBIE_VARIANT_NAMES: dict[int, str] = {
    0x36: "Zombie Spree (v0x36)",
    0x37: "Zombie Spree (v0x37)",
    0x38: "Zombie Spree (v0x38)",
    0x39: "Zombie Spree (v0x39)",
    0x3A: "Zombie Spree (v0x3A)",
    0x3B: "Zombie Spree (v0x3B)",
}

_FRANK_ZOMBIE_FALL_NAMES = {"Zombie Fall", "Zombie fall"}
_FRANK_ZOMBIE_FALL_OFF = 0x19BE
_FRANK_ZOMBIE_ATTACK_OFF = 0x0B14
_FRANK_ZOMBIE_SPREE_OFF  = 0x7C4C

_FRANK_ZOMBIE_SPREE_KBY_L = 0x12E
_FRANK_ZOMBIE_SPREE_KBY_M = 0x17E
_FRANK_ZOMBIE_SPREE_KBY_H = 0x1CE

_FRANK_ZOMBIE_SPREE_ARC_L   = 0x122
_FRANK_ZOMBIE_SPREE_ACCEL_L = 0x142

_FRANK_ZOMBIE_SPREE_ARC_M   = 0x172
_FRANK_ZOMBIE_SPREE_ACCEL_M = 0x192

_FRANK_ZOMBIE_SPREE_ARC_H   = 0x1C2
_FRANK_ZOMBIE_SPREE_ACCEL_H = 0x1E2

_FRANK_ZOMBIE_ATTACK_SPEED_A = 0x7E
_FRANK_ZOMBIE_ATTACK_SPEED_A = 0x7E
_FRANK_ZOMBIE_ATTACK_ACCEL_A = 0x92
_FRANK_ZOMBIE_ATTACK_SPAWN_X = 0x159
_FRANK_ZOMBIE_FALL_DMG_OFF = 0x04
_FRANK_ZOMBIE_FALL_SPAWN_Y_OFF = 0xA6
# Exact per-slot ownership ranges derived from chr_tbl analysis notes.
# Each tuple is (chr_tbl_base, move_data_start, max_referenced_addr + slack).
# Using tight bounds prevents cross-slot false positives.
_CHR_TBL_RANGES = [
    (0x90896640, 0x90896640, 0x908D2000),            # slot 0
    (0x908F1920, 0x908F1920, 0x9092B634 + 0x2000),   # slot 1
    (0x909478E0, 0x909478E0, 0x909BE310 + 0x2000),   # slot 2
    (0x9099D9C0, 0x9099D9C0, 0x909DECAC + 0x2000),   # slot 3
]

def _owning_chr_tbl(addr: int) -> int | None:
    """
    Dynamic ownership:
    assign the hit to the closest chr_tbl base within a sane forward window.
    This avoids hardcoding slot-specific end ranges that can miss valid data.
    """
    best_base = None
    best_dist = None

    for base in _current_chr_tbl_bases():
        if addr < base:
            continue
        dist = addr - base
        if dist > 0x90000:   # generous window; adjust if needed
            continue
        if best_dist is None or dist < best_dist:
            best_dist = dist
            best_base = base

    return best_base

def _key_for_hit_addr(addr: int, slot_char_ids: dict[int, int] | None) -> str | None:
    if not slot_char_ids:
        return None
    base = _owning_chr_tbl(addr)
    if base is None:
        return None
    cid = slot_char_ids.get(base)
    if cid is None:
        return None
    return _projectile_key_from_char_id(cid)
def _is_frank_zombie_move_label(move: str) -> bool:
    s = str(move or "").lower()
    return "zombie" in s

def _is_frank_zombie_fall_label(move: str) -> bool:
    return str(move or "") in _FRANK_ZOMBIE_FALL_NAMES

def _apply_frank_zombie_anchor(hits: list[dict]) -> list[dict]:
    """
    Frank-specific override:
      - if a real Zombie Fall row exists, use it as anchor
      - otherwise synthesize Zombie Fall from the owning chr_tbl base
      - derive Attack/Spree from Fall
    """
    anchored_rows: list[dict] = []
    anchor_bases: set[int] = set()
    fall_by_base: dict[int, dict] = {}
    zombie_base_seed: dict[int, dict] = {}

    for h in hits:
        if h.get("key") != "FRANK":
            continue

        base = _owning_chr_tbl(h.get("addr", 0))
        if base is None:
            continue

        if _is_frank_zombie_move_label(h.get("move", "")):
            zombie_base_seed.setdefault(base, h)

        if _is_frank_zombie_fall_label(h.get("move", "")):
            fall_by_base.setdefault(base, h)

    for base, seed in zombie_base_seed.items():
        fall_hit = fall_by_base.get(base)
        if fall_hit is None:
            fall_addr = base + _FRANK_ZOMBIE_FALL_OFF
            fall_hit = {
                **seed,
                "addr": fall_addr,
                "move": "Zombie Fall",
                "dmg": 3200,
                "fmt": "frank_zoml",
                "cluster": f"frank zombie anchor @ 0x{fall_addr:08X}",
                "dmg_write_addr": fall_addr + _FRANK_ZOMBIE_FALL_DMG_OFF,
            }

        anchor_bases.add(base)
        fall_addr   = int(fall_hit["addr"])
        attack_addr = fall_addr + _FRANK_ZOMBIE_ATTACK_OFF
        spree_addr  = fall_addr + _FRANK_ZOMBIE_SPREE_OFF - 4

        anchored_rows.append({
            **fall_hit,
            "addr": fall_addr,
            "move": "Zombie Fall",
            "dmg": 3200,
            "cluster": f"frank zombie anchor @ 0x{fall_addr:08X}",
            "dmg_write_addr": fall_addr + _FRANK_ZOMBIE_FALL_DMG_OFF,
            "spawn_y": _read_f32(fall_addr + _FRANK_ZOMBIE_FALL_SPAWN_Y_OFF),
        })

        anchored_rows.append({
            **fall_hit,
            "addr": attack_addr,
            "move": "Zombie Attack",
            "dmg": 2400,
            "cluster": f"frank zombie anchor @ 0x{fall_addr:08X}",
            "dmg_write_addr": base + _SCRIPT_DMG_OFFSETS[2400],
            "speed":   _read_f32(attack_addr + _FRANK_ZOMBIE_ATTACK_SPEED_A),
            "accel":   _read_f32(attack_addr + _FRANK_ZOMBIE_ATTACK_ACCEL_A),
            "spawn_x": _read_u8(attack_addr + _FRANK_ZOMBIE_ATTACK_SPAWN_X),
        })
        
        anchored_rows.append({
            **fall_hit,
            "addr": spree_addr,
            "move": "Zombie Spree L",
            "dmg": 2400,
            "cluster": f"frank zombie anchor @ 0x{fall_addr:08X}",
            "dmg_write_addr": base + _SCRIPT_DMG_OFFSETS[2400],
            "arc":   _read_f32(spree_addr + _FRANK_ZOMBIE_SPREE_ARC_L),
            "kb_y":  _read_f32(spree_addr + _FRANK_ZOMBIE_SPREE_KBY_L),
            "speed": _read_f32(spree_addr + _FRANK_ZOMBIE_SPREE_ACCEL_L),
        })

        anchored_rows.append({
            **fall_hit,
            "addr": spree_addr,
            "move": "Zombie Spree M",
            "dmg": 2400,
            "cluster": f"frank zombie anchor @ 0x{fall_addr:08X}",
            "dmg_write_addr": base + _SCRIPT_DMG_OFFSETS[2400],
            "arc":   _read_f32(spree_addr + _FRANK_ZOMBIE_SPREE_ARC_M),
            "kb_y":  _read_f32(spree_addr + _FRANK_ZOMBIE_SPREE_KBY_M),
            "speed": _read_f32(spree_addr + _FRANK_ZOMBIE_SPREE_ACCEL_M),
        })

        anchored_rows.append({
            **fall_hit,
            "addr": spree_addr,
            "move": "Zombie Spree H",
            "dmg": 2400,
            "cluster": f"frank zombie anchor @ 0x{fall_addr:08X}",
            "dmg_write_addr": base + _SCRIPT_DMG_OFFSETS[2400],
            "arc":   _read_f32(spree_addr + _FRANK_ZOMBIE_SPREE_ARC_H),
            "kb_y":  _read_f32(spree_addr + _FRANK_ZOMBIE_SPREE_KBY_H),
            "speed": _read_f32(spree_addr + _FRANK_ZOMBIE_SPREE_ACCEL_H),
        })

    if not anchor_bases:
        return hits

    kept: list[dict] = []
    for h in hits:
        if (
            h.get("key") == "FRANK"
            and _is_frank_zombie_move_label(h.get("move", ""))
            and _owning_chr_tbl(h.get("addr", 0)) in anchor_bases
        ):
            continue
        kept.append(h)

    kept.extend(anchored_rows)
    kept.sort(key=lambda x: (int(x.get("addr", 0)), str(x.get("move", ""))))
    return kept
# ---------------------------------------------------------------------------
# Main scan thread
# ---------------------------------------------------------------------------
def _scan_zombie_blocks(data: bytes, base_addr: int, hits: list,
                         lookup: dict, seen_variants: set,
                         slot_char_ids: dict | None = None) -> None:
    """
    Disabled for now.
    Raw zombie spree variants stay suppressed.
    """
    return
def _looks_like_super_dispatch_0023(data: bytes, idx: int) -> bool:
    'Return True when a 00/23 match is a super/action dispatch row.\n\n    Compact projectile-super cards and super dispatch rows both begin with\n    00 23 00 00.  Dispatch rows are not projectile payloads: at +0x02 they\n    hold the action selector u32, at +0x06 variant, at +0x0A phase length, and\n    at +0x16 a child script link.  If the module let the projectile scanner own these,\n    rows like Morrigan selector 0x60 become fake "damage 96" bullets.\n    '
    try:
        if idx < 0 or idx + 0x1A > len(data):
            return False
        if data[idx:idx + 2] != b"\x00\x23":
            return False
        selector = struct.unpack_from(">I", data, idx + 0x02)[0]
        variant = struct.unpack_from(">I", data, idx + 0x06)[0]
        phase = struct.unpack_from(">I", data, idx + 0x0A)[0]
        param_a = struct.unpack_from(">I", data, idx + 0x0E)[0]
        param_b = struct.unpack_from(">I", data, idx + 0x12)[0]
        child_link = struct.unpack_from(">I", data, idx + 0x16)[0]
    except Exception:
        return False

    # Confirmed Ryu/Shinkuu and Morrigan rows use small selectors and sane
    # phase values, then jump through a 00/04xxxx-style script link.
    if not (0 <= selector <= 0x200):
        return False
    if not (0 <= variant <= 0x200):
        return False
    if not (0 <= phase <= 0x400):
        return False
    if not (0 <= param_a <= 0x400 and 0 <= param_b <= 0x400):
        return False
    if not (0x00010000 <= child_link <= 0x00090000):
        return False
    return True


def _read_projectile_super_field(addr: int, name: str):
    off, typ = _PROJECTILE_SUPER_FIELD_OFFSETS.get(name, (None, None))
    if off is None:
        return "?"
    a = int(addr) + int(off)
    if typ == "f32":
        return _read_f32(a)
    if typ == "u16":
        return _read_u16(a)
    if typ == "u32":
        return _read_u32(a)
    if typ == "u8":
        return _read_u8(a)
    return "?"

def _projectile_super_case_label(slot_key: str | None, owner_base: int | None, addr: int, dmg: int, card_type: int) -> str | None:
    """Best-effort case names for compact projectile-super cards farmed from dumps."""
    rel = int(addr) - int(owner_base or 0) if owner_base else None
    if slot_key == "MORRIGAN":
        # Finishing Shower is a dense table of small 00/23 bullet cards.
        if 0x4B000 <= int(rel or 0) <= 0x4E800 and 20 <= int(dmg) <= 140:
            return "Finishing Shower Bullet"
        return "Morrigan Projectile Super Card"
    if slot_key == "VOLNUTT":
        if int(dmg) == 480:
            return "Machine Gun Sweep"
        if int(dmg) == 2000:
            return "Machine Gun Sweep Super Card"
        return None
    if slot_key == "TEKKAMAN":
        if int(dmg) == 1280:
            return "Voltekka (Ground)"
        if int(dmg) == 720:
            return "Voltekka Projectile Card"
        if int(dmg) == 1760:
            return "Disco Ball Card"
        if int(dmg) == 1920:
            return "Voltekka Projectile Card"
        return None
    if slot_key == "CASSHAN":
        if int(dmg) == 1440:
            return "Brutal Ax"
        if int(dmg) in (960, 1040):
            return "Casshan Projectile Super Card"
        return None
    return None

def _append_projectile_super_card(hits: list, lookup: dict, char_damage_map: dict,
                                  slot_char_ids: dict[int, int] | None,
                                  addr: int, dmg: int, fmt: str, card_type: int) -> None:
    owner_base = _owning_chr_tbl(addr)
    if owner_base is None:
        return
    slot_key = _key_for_hit_addr(addr, slot_char_ids)
    active_keys = _active_keys_from_lookup(lookup)
    if active_keys and slot_key not in active_keys:
        return

    move = _projectile_super_case_label(slot_key, owner_base, addr, int(dmg), int(card_type))
    if move is None and slot_key is not None:
        mapped = char_damage_map.get(slot_key, {}).get(int(dmg), [])
        if mapped:
            move = mapped[0]
        elif int(dmg) < 500:
            return
        else:
            move = "Projectile Super Card"
    if move is None:
        if int(dmg) < 500:
            # Low-damage cards are usually tables; without ownership/context they
            # are too noisy to show.
            return
        move = "Projectile Super Card"

    hit = {
        "addr": int(addr),
        "dmg": int(dmg),
        "fmt": fmt,
        "dmg_write_addr": int(addr) + 0x04,
        **_OPCODE_HIT_FIELDS,
        "cluster": f"projectile super {card_type:04X} @ 0x{int(addr):08X}",
        "key": slot_key or "?",
        "move": move,
        "ps_card_type": int(card_type),
    }
    for name in _PROJECTILE_SUPER_FIELD_OFFSETS:
        hit[name] = _read_projectile_super_field(int(addr), name)
    # Make common template columns useful for these rows too.
    hit["lifetime"] = hit.get("ps_lifetime")
    hit["hitbox"] = hit.get("ps_scale")
    hit["speed"] = hit.get("ps_offset_x")
    hit["accel"] = hit.get("ps_offset_y")
    hits.append(hit)

def _append_super_hit(hits: list, lookup: dict, char_damage_map: dict,
                      slot_char_ids: dict[int, int] | None,
                      addr: int, dmg, fmt: str, dmg_write_addr: int,
                      cluster: str, extra: dict | None = None):
    hit_base = {
        "addr": addr,
        "dmg": dmg,
        "fmt": fmt,
        "dmg_write_addr": dmg_write_addr,
        **_OPCODE_HIT_FIELDS,
        "cluster": cluster,
    }
    if extra:
        hit_base.update(extra)
    if fmt in ("super_struct", "super_struct_card", "super_struct_card2", "super_beam_card"):
        ex_base = _super_ex_base(addr, fmt)
        ex03c = _read_f32(ex_base + _SUPER_EX_OFFSETS["ex03c"])
        def _read_named_super_field(name: str):
            off, typ = _SUPER_FIELD_OFFSETS.get(name, (None, None))
            if off is None:
                return "?"
            a = ex_base + int(off)
            if typ == "f32":
                return _read_f32(a)
            if typ == "u16":
                return _read_u16(a)
            if typ == "u32":
                return _read_u32(a)
            if typ == "u8":
                return _read_u8(a)
            return "?"

        for _name in _SUPER_FIELD_OFFSETS.keys():
            hit_base[_name] = _read_named_super_field(_name)

        hit_base.update({
            "ex03c": ex03c,
            "ex060": _read_f32(ex_base + _SUPER_EX_OFFSETS["ex060"]),
            "ex090": _read_f32(ex_base + _SUPER_EX_OFFSETS["ex090"]),
            "ex094": _read_f32(ex_base + _SUPER_EX_OFFSETS["ex094"]),
            "ex09c": _read_f32(ex_base + _SUPER_EX_OFFSETS["ex09c"]),
            "ex0d4": _read_f32(ex_base + _SUPER_EX_OFFSETS["ex0d4"]),
            "ex0e4": _read_f32(ex_base + _SUPER_EX_OFFSETS["ex0e4"]),
        })
        hit_base["hitbox"] = ex03c

    # Prefer slot-owned character resolution first.
    if isinstance(dmg, int):
        slot_key = _key_for_hit_addr(addr, slot_char_ids)
        active_keys = _active_keys_from_lookup(lookup)

        # Canonical super-beam rows need an owning-slot fallback before global
        # damage lookup.  If the slot is known and selected, use the character's
        # known beam-super name when its per-hit damage is not in the map.
        # Do not use selected-character fallback without slot ownership; that
        # would mislabel another slot's beam card when scanning all MEM2.
        if (
            fmt == "super_beam_card"
            and slot_key in _SUPER_BEAM_DEFAULT_MOVE_BY_KEY
            and (not active_keys or slot_key in active_keys)
        ):
            slot_moves = char_damage_map.get(slot_key, {}).get(dmg, [])
            if not slot_moves:
                hits.append({
                    **hit_base,
                    "key": slot_key,
                    "move": _SUPER_BEAM_DEFAULT_MOVE_BY_KEY[slot_key],
                })
                return
        if slot_key is not None:
            moves = char_damage_map.get(slot_key, {}).get(dmg, [])
            if moves and (not active_keys or slot_key in active_keys):
                for mv in moves:
                    hits.append({**hit_base, "key": slot_key, "move": mv})
                return
            if active_keys and slot_key not in active_keys:
                return
            # Same selected character, but damage is not in the name map. Keep it
            # as a candidate instead of misnaming it from another character.
            hits.append({**hit_base, "key": "?", "move": "Super Struct Candidate"})
            return

        # Fallback to the old global lookup only when ownership is unknown.
        if dmg in lookup:
            for key, mv in lookup[dmg]:
                hits.append({**hit_base, "key": key, "move": mv})
            return

    hits.append({**hit_base, "key": "?", "move": "Super Struct Candidate"})


def _super_ex_base(addr: int, fmt: str) -> int:
    if fmt == "super_struct":
        return addr - 0x09
    if fmt == "super_struct_card":
        return addr - 0x0E
    if fmt == "super_struct_card2":
        return addr - 0x0C
    if fmt == "super_beam_card":
        return addr
    return addr


def _super_probe_string(ex_base: int, max_items: int = 28) -> str:
    """
    Compact experimental dump for super structs.

    Reads 0x120 bytes from the inferred local base and reports plausible
    aligned f32/u16 values. This is intentionally noisy: the point is to
    expose candidate lifetime/radius/speed/scale fields quickly.
    """
    if rbytes is None:
        return "?"
    try:
        data = rbytes(ex_base, 0x120)
    except Exception:
        data = b""
    if not data or len(data) < 0x20:
        return "?"

    out = []

    def _add(label: str, val: str):
        if len(out) < max_items:
            out.append(f"{label}={val}")

    # Floats: good for radius/speed/scale/gravity/arc.
    for off in range(0, min(len(data) - 4, 0x120), 4):
        try:
            f = struct.unpack_from(">f", data, off)[0]
        except Exception:
            continue
        if not (-5000.0 <= f <= 5000.0):
            continue
        af = abs(f)
        # Skip pure zeros and denormal-looking trash; keep common constants.
        if af == 0.0 or (0.0 < af < 0.0001):
            continue
        if af <= 5000.0:
            _add(f"F{off:03X}", f"{f:.3g}")

    # U16s: good for damage/lifetime/type/id/flags.
    for off in range(0, min(len(data) - 2, 0x120), 2):
        try:
            u = struct.unpack_from(">H", data, off)[0]
        except Exception:
            continue
        if u in (0, 1, 4, 10, 12, 35, 255, 256, 512, 1024, 1200, 1600, 2000, 2400, 3200, 4800, 5200, 6000, 10000):
            _add(f"U{off:03X}", str(u))
        elif 2 <= u <= 240 and off % 2 == 0:
            # possible timers / small flags / type bytes packed into u16
            _add(f"U{off:03X}", str(u))

    return " ".join(out) if out else "?"

def _scan_super_struct_blocks(data: bytes, base_addr: int, hits: list,
                              lookup: dict, char_damage_map: dict,
                              slot_char_ids: dict[int, int] | None) -> None:
    beam_ranges: list[tuple[int, int]] = []

    def _inside_beam_range(addr: int) -> bool:
        try:
            a = int(addr)
        except Exception:
            return False
        for lo, hi in beam_ranges:
            if lo <= a < hi:
                return True
        return False

    # ── Pass 0: real super beam card ──────────────────────────────────────
    # Shape seen on Ryu Shinkuu / Chun Kikosho:
    #   base+0x08 = 0000000C
    #   base+0x0C = 00000023
    #   base+0x10 = damage u32
    # This keeps the row anchored to the real card base, not the shifted 0x23
    # signature used by the older exploratory scanner.
    pos = 0
    beam_sig = b"\x00\x00\x00\x0C\x00\x00\x00\x23"
    while True:
        sig_i = data.find(beam_sig, pos)
        if sig_i < 0:
            break
        pos = sig_i + 1
        idx = sig_i - 8
        if idx < 0:
            continue
        if idx + 0x158 > len(data):
            continue

        block_addr = base_addr + idx
        if _owning_chr_tbl(block_addr) is None:
            continue

        dmg = _read_u32_int(block_addr + 0x10)
        if not isinstance(dmg, int) or not (2 <= dmg <= 30000):
            continue

        # Soft validation: lifetime/count/particle fields should be sane, but
        # do not overfit because other supers may use different ids/counts.
        # Some valid cards use 0xFFFFFFFF / 0xFFFFFFFE as sentinel values.
        lifetime = _read_u32_int(block_addr + 0x84)
        hit_count = _read_u32_int(block_addr + 0x24)
        if isinstance(lifetime, int) and lifetime not in (0xFFFFFFFF, 0xFFFFFFFE) and lifetime > 0x10000:
            continue
        if isinstance(hit_count, int) and hit_count > 0x10000:
            continue

        beam_ranges.append((block_addr, block_addr + 0x160))

        _append_super_hit(
            hits, lookup, char_damage_map, slot_char_ids,
            block_addr, dmg, "super_beam_card", block_addr + 0x10,
            f"super beam @ 0x{block_addr:08X}",
            {
                "opcode": _read_u16_hex(block_addr),
                "param1": _read_u16_hex(block_addr + 2),
                "param2": _read_u16_hex(block_addr + 4),
                "param3": _read_u16_hex(block_addr + 6),
            }
        )

    # ── Pass 1: original sig  00 00 0C 00 00 00 23 00 ─────────────────────
    pos = 0
    while True:
        idx = data.find(SUPER_STRUCT_SIG, pos)
        if idx < 0:
            break
        pos = idx + 1

        block_addr = base_addr + idx
        if _owning_chr_tbl(block_addr) is None:
            continue
        if _inside_beam_range(block_addr):
            continue

        window_end = min(idx + SUPER_VERIFY_LOOK, len(data))
        window = data[idx:window_end]
        if not (SUPER_VERIFY_A in window or SUPER_VERIFY_B in window):
            continue

        dmg_addr = block_addr + _SUPER_STRUCT_DMG_OFF
        dmg = "?"
        if rbytes is not None:
            try:
                b = rbytes(dmg_addr, 2)
                if b and len(b) == 2:
                    dmg = (b[0] << 8) | b[1]
            except Exception:
                pass

        _append_super_hit(
            hits, lookup, char_damage_map, slot_char_ids,
            block_addr, dmg, "super_struct", dmg_addr,
            f"super struct @ 0x{block_addr:08X}"
        )

    # ── Pass 2: wildcard sig  ?? 23 00 00 00 [dmg hi] [dmg lo] 00 00 00 00
    pos = 0
    while True:
        idx = data.find(b"\x23\x00\x00\x00", pos)
        if idx < 0:
            break
        pos = idx + 1

        block_addr = base_addr + idx
        if _owning_chr_tbl(block_addr) is None:
            continue
        if _inside_beam_range(block_addr):
            continue

        dmg_off = idx + 4
        if dmg_off + 6 > len(data):
            continue

        dmg = (data[dmg_off] << 8) | data[dmg_off + 1]
        if not (2 <= dmg <= 20000):
            continue
        
        if data[dmg_off + 2 : dmg_off + 6] != b"\x00\x00\x00\x00":
            continue

        dmg_addr = base_addr + dmg_off

        _append_super_hit(
            hits, lookup, char_damage_map, slot_char_ids,
            block_addr, dmg, "super_struct", dmg_addr,
            f"super struct2 @ 0x{block_addr:08X}"
        )


    # ── Pass 3: compact projectile-super card  01 23 00 00 [dmg hi] [dmg lo]
    pos = 0
    while True:
        idx = data.find(b"\x01\x23\x00\x00", pos)
        if idx < 0:
            break
        pos = idx + 1

        block_addr = base_addr + idx
        if _owning_chr_tbl(block_addr) is None:
            continue
        if _inside_beam_range(block_addr):
            continue
        if idx + 0x60 > len(data):
            continue

        dmg = (data[idx + 4] << 8) | data[idx + 5]
        life = (data[idx + 8] << 8) | data[idx + 9]
        if not (2 <= dmg <= 30000 and 0 <= life <= 0x400):
            continue

        _append_projectile_super_card(
            hits, lookup, char_damage_map, slot_char_ids,
            block_addr, dmg, "projectile_super_card_0123", 0x0123
        )

    # ── Pass 4: compact projectile-super card  00 23 00 00 [dmg hi] [dmg lo] ...
    pos = 0
    while True:
        idx = data.find(b"\x00\x23\x00\x00", pos)
        if idx < 0:
            break
        pos = idx + 1

        if _looks_like_super_dispatch_0023(data, idx):
            # Super/action caller rows are handled by fd_super_integration.
            # They are not projectile payload cards.
            continue

        block_addr = base_addr + idx
        if _owning_chr_tbl(block_addr) is None:
            continue
        if _inside_beam_range(block_addr):
            continue
        if idx + 0x60 > len(data):
            continue

        dmg = (data[idx + 4] << 8) | data[idx + 5]
        life = (data[idx + 8] << 8) | data[idx + 9]
        count = (data[idx + 0x0C] << 8) | data[idx + 0x0D]
        # Low damage is important for Morrigan-style projectile-super tables,
        # but require sane card values so ordinary data does not flood the UI.
        if not (2 <= dmg <= 30000 and 0 <= life <= 0x400 and 0 <= count <= 0x400):
            continue

        _append_projectile_super_card(
            hits, lookup, char_damage_map, slot_char_ids,
            block_addr, dmg, "projectile_super_card", 0x0023
        )
 


def _scan_morrigan_finishing_shower_missile(data: bytes,
                                            base_addr: int,
                                            hits: list,
                                            active_keys,
                                            slot_char_ids: dict[int, int] | None,
                                            seen_fs_missiles: set[int]) -> None:
    "Find Morrigan Finishing Shower's live missile template.\n\n    This block is not the normal 00 00 dmg / 00 00 00 0C projectile-template\n    layout, and it is not the later 00/23 card-list table.  Operator pokes\n    confirmed this live record shape:\n\n      base + 0x06 = u16 damage, 0x0320 / 800\n      base + 0x30 = f32 radius\n      base + 0x34 = u32 FX / hit effect ID\n      base + 0x5F = u8 spawn origin / bone-ish selector\n      base + 0x90 = f32 travel speed\n      base + 0xD8 = f32 secondary radius / hitbox radius\n\n    Canonical example: base 0x908E2900, damage 0x908E2906, speed 0x908E2990, secondary radius 0x908E29D8.\n    "
    try:
        if "MORRIGAN" not in {str(k).upper() for k in (active_keys or [])}:
            return
    except Exception:
        return
    if not data:
        return

    # Damage lives inside this record, so do not include 0x0320 in the
    # signature.  Otherwise the row disappears after the operator edits damage.
    sig = b"\x00\x00\x01\x03"
    start = 0
    while True:
        off = data.find(sig, start)
        if off < 0:
            break
        if off + 0x94 > len(data):
            start = off + 1
            continue
        # Confirm the local invariant bytes from the known 0x908E2900 block.
        if data[off + 0x08:off + 0x10] != b"\x00\x00\x00\x10\x00\x00\x00\x01":
            start = off + 1
            continue
        a = base_addr + off
        start = off + 1
        if a in seen_fs_missiles:
            continue
        if slot_char_ids:
            try:
                if _key_for_hit_addr(a, slot_char_ids) != "MORRIGAN":
                    continue
            except Exception:
                continue
        # Soft validators from the current confirmed memory page.  Keep them
        # permissive so altered values do not make the row disappear mid-edit.
        try:
            dmg = _read_u16(a + 0x06)
            kb_x = _read_f32(a + 0x28)
            kb_y = _read_f32(a + 0x2C)
            radius = _read_f32(a + 0x30)
            fx = _read_u32(a + 0x34)
            spawn_origin = _read_u8(a + 0x5F)
            speed = _read_f32(a + 0x90)
            hitbox = _read_f32(a + 0xD8)
            pid = _read_u16(a + 0x52)
            ptype = _read_u8(a + 0x51)
        except Exception:
            dmg = speed = radius = fx = spawn_origin = pid = ptype = kb_x = kb_y = hitbox = "?"
        hits.append({
            "addr": a,
            "key": "MORRIGAN",
            "move": "Finishing Shower Missile",
            "dmg": dmg,
            "dmg_write_addr": a + 0x06,
            "fmt": "morrigan_fs_missile",
            "cluster": "confirmed live missile template",
            "proj_role": "confirmed",
            "type": ptype,
            "id": pid,
            "radius": radius,
            "fx": fx,
            "spawn_origin": spawn_origin,
            "speed": speed,
            "accel": "?",
            "kb_x": kb_x,
            "kb_y": kb_y,
            "hitbox": hitbox,
            "arc": "?",
            "arc2": "?",
        })
        seen_fs_missiles.add(a)

def _run_scan(active_keys, progress_cb, done_cb, show_unknowns: bool = True):
    if rbytes is None:
        done_cb([]); return

    proj_map = _load_map()
    id_map   = _load_ids()
    lookup   = _build_lookup(proj_map, active_keys)
    char_damage_map = _build_char_damage_map(proj_map)

    # Read live char_id per slot so zombie block scanner can gate on Frank.
    slot_char_ids = _read_slot_char_ids()

    total = SCAN_END - SCAN_START
    hits  = []
    addr  = SCAN_START
    seen_zombie_variants: set = set()
    seen_fs_missiles: set[int] = set()

    while addr < SCAN_END:
        sz = min(SCAN_BLOCK, SCAN_END - addr)
        try:
            data = rbytes(addr, sz)
        except Exception:
            data = b""

        if data:
            _scan_opcode_blocks(data, addr, hits, lookup, slot_char_ids)
            _scan_suffix_blocks(data, addr, hits, lookup, id_map, slot_char_ids)
            _scan_zombie_blocks(data, addr, hits, lookup, seen_zombie_variants, slot_char_ids)
            _scan_morrigan_finishing_shower_missile(data, addr, hits, active_keys, slot_char_ids, seen_fs_missiles)
            _scan_super_struct_blocks(data, addr, hits, lookup, char_damage_map, slot_char_ids)
        progress_cb((addr - SCAN_START + sz) / total * 100.0)
        addr += sz
    _annotate_clusters(hits)

    # Frank-specific zombie handling:
    # ignore Frank move-ID association except Zombie Fall,
    # then derive Attack/Spree from the discovered Fall row.
    hits = _apply_frank_zombie_anchor(hits)

    if not show_unknowns:
        hits = [h for h in hits if not (h.get("key") == "?" and h.get("move") == "Unknown")]

    _dump_hits(hits)
        

    
    done_cb(hits)


def _dump_hits(hits: list, context: int = 0x100):
    if rbytes is None or not hits:
        return
    super_hits = [
        h for h in hits
        if h.get("fmt") in ("super_struct", "super_struct_card", "super_struct_card2", "super_beam_card")
    ]
    if not super_hits:
        return
    try:
        dump_path = user_data_path("runtime", "proj_dump.bin")
        os.makedirs(os.path.dirname(dump_path), exist_ok=True)
        with open(dump_path, "wb") as f:
            for h in super_hits:
                base = max(h["addr"] - context, SCAN_START)
                size = min(context * 2, SCAN_END - base)
                try:
                    data = rbytes(base, size)
                except Exception:
                    data = b""
                f.write(base.to_bytes(4, "big"))
                f.write(h["addr"].to_bytes(4, "big"))
                f.write(len(data).to_bytes(4, "big"))
                f.write(data)
        print(f"[proj_scanner] dumped {len(super_hits)} super_struct hit(s) to {dump_path}")
    except Exception as e:
        print(f"[proj_scanner] dump failed: {e}")
# ---------------------------------------------------------------------------
# Column definitions
# kb_x / kb_y replace aerial_kb_x / aerial_kb_y
# cluster column added
# ---------------------------------------------------------------------------
_COLS = [
    ("address",  "Address",   None,       False),
    ("char",     "Char",      None,       False),
    ("move",     "Move",      None,       False),
    ("dmg",      "Damage",    "dmg",      False),
    ("cluster",  "Cluster",   None,       False),

    # Named super fields. These are editable for super rows.
    ("super_lifetime",     "Lifetime",     "super_lifetime", False),
    ("super_hit_count",    "Hit Count",    "super_hit_count", False),
    ("super_hit_interval", "Hit Interval", "super_hit_interval", False),
    ("super_particle_fx",  "Particle FX",  "super_particle_fx", False),
    ("super_spawn_bone",   "Spawn Bone",   "super_spawn_bone", False),
    ("super_hit_source",   "Hit Source",   "super_hit_source", False),
    ("super_air_kb_y",     "Beam Scale",   "super_air_kb_y", True),
    ("super_beam_width",   "Beam Width",   "super_beam_width", True),
    ("super_speed",        "Beam Speed",   "super_speed", True),
    ("super_accel",        "Beam Force",   "super_accel", True),
    ("super_radius",       "Hit Radius",   "super_radius", True),
    ("super_beam_visual",  "Beam Visual",  "super_beam_visual", False),
    ("super_final_damage",      "Final Damage",   "super_final_damage", False),
    ("super_final_lifetime",    "Final Life",     "super_final_lifetime", False),
    ("super_final_particle_fx", "Final FX",       "super_final_particle_fx", False),
    ("super_final_spawn_bone",  "Final Bone",     "super_final_spawn_bone", False),
    # Older exploratory slots kept for farming other supers.
    ("super_hit_react",    "HitReact",     "super_hit_react", False),
    ("super_life",         "OldLife?",     "super_life", False),
    ("super_speed_2",      "SuperSpeed2?", "super_speed_2", True),
    ("super_accel_b",      "AccelB?",      "super_accel_b", True),
    ("super_accel_c",      "AccelC?",      "super_accel_c", True),
    ("super_multihit_cap", "UnknownD8",    "super_multihit_cap", False),

    # Standard projectile/template fields.
    ("radius",   "Radius",    "radius",   True),
    ("speed",    "Speed",     "speed",    True),
    ("accel",    "Accel",     "accel",    True),
    ("kb_x",     "KB X",      "kb_x",     True),
    ("kb_y",     "KB Y",      "kb_y",     True),
    ("arc",      "Arc",       "arc",      True),
    ("arc2",     "Arc2",      "arc2",     True),
    ("spawn_x",  "Spawn X",   "spawn_x",  False),
    ("spawn_y",  "Spawn Y",   "spawn_y",  True),
    ("hitbox",   "Hitbox",    "hitbox",   True),
    ("type",     "Type",      "type",     False),
    ("id",       "ID",        "id",       False),
    ("lifetime", "Lifetime",  "lifetime", False),
    ("hb_size",  "HB Size",   "hb_size",  False),
    ("fmt",      "Fmt",       None,       False),
]
_COL_IDS    = [c[0] for c in _COLS]
_FMT_COL_IDX = _COL_IDS.index("fmt")


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------
class ProjScannerWindow:
    def __init__(self, master, get_active_fn):
        self._get_active = get_active_fn
        self._scanning   = False
        self._keys: set  = set()
        self._addr_by_iid: dict[str, int] = {}
        self._dmg_write_by_iid: dict[str, int] = {}
        self._show_unknowns = tk.BooleanVar(value=True)

        self.root = tk.Toplevel(master)
        self.root.title("Projectile Definition Scanner")
        self.root.geometry("1100x560")
        self.root.protocol("WM_DELETE_WINDOW", self.root.destroy)

        self._build()
        self._auto_scan()

    def _build(self):
        top = ttk.Frame(self.root)
        top.pack(side="top", fill="x", padx=8, pady=6)
        self._active_var = tk.StringVar(value="Active: --")
        ttk.Label(top, textvariable=self._active_var).pack(side="left")
        ttk.Checkbutton(
            top, text="Show unknowns",
            variable=self._show_unknowns,
            command=self._start,
        ).pack(side="right", padx=8)
        self._scan_btn = ttk.Button(top, text="Rescan", command=self._start)
        self._scan_btn.pack(side="right", padx=4)

        self._prog = tk.DoubleVar()
        ttk.Progressbar(self.root, variable=self._prog, maximum=100).pack(
            fill="x", padx=8, pady=(0, 4))
        self._status = tk.StringVar(value="Scanning...")
        ttk.Label(self.root, textvariable=self._status, anchor="w").pack(fill="x", padx=8)

        frame = ttk.Frame(self.root)
        frame.pack(fill="both", expand=True, padx=8, pady=6)

        self._tree = ttk.Treeview(frame, columns=_COL_IDS, show="headings", height=24)
        widths = {"address": 110, "char": 80, "move": 160, "dmg": 65,
                  "cluster": 220, "super_hit_react": 90, "super_life": 90,
                  "super_air_kb_y": 100, "super_speed": 110, "super_accel": 110,
                  "super_speed_2": 90, "super_accel_b": 90, "super_accel_c": 90,
                  "super_multihit_cap": 90, "super_radius": 105,
                  "speed": 75, "accel": 75, "arc": 75}
        self._sort_col = None
        self._sort_asc = True

        col_map = {c[0]: c[1] for c in _COLS}
        for col_id, header, _, _ in _COLS:
            self._tree.heading(col_id, text=header,
                command=lambda c=col_id: self._sort_by(c))
            self._tree.column(col_id, width=widths.get(col_id, 65), anchor="center")
        self._tree.column("move",    anchor="w")
        self._tree.column("cluster", anchor="w")

        vsb = ttk.Scrollbar(frame, orient="vertical", command=self._tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=self._tree.xview)
        self._tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self._tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        frame.grid_rowconfigure(0, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        self._tree.bind("<Double-Button-1>", self._on_double_click)
        self._tree.bind("<Button-3>",        self._on_right_click)


        ttk.Label(self.root,
                  text="Double-click editable fields to write. Right-click any cell to copy/go to its address. AirKBY/SuperSpeed2/MultiHitCap/AccelC are experimental probes.",
                  foreground="gray").pack(anchor="w", padx=8, pady=(0, 4))

    def _auto_scan(self):
        names = self._get_active()
        self._keys = {_NAME_TO_KEY[n] for n in names if n in _NAME_TO_KEY}
        self._active_var.set(f"Active: {', '.join(sorted(names)) or 'none'}")
        self._start()

    def _start(self):
        if self._scanning:
            return
        names = self._get_active()
        self._keys = {_NAME_TO_KEY[n] for n in names if n in _NAME_TO_KEY}
        self._active_var.set(f"Active: {', '.join(n for n in names if n) or 'none'}")
        if not self._keys:
            self._status.set("No active characters with known projectiles.")
            return
        self._scanning = True
        self._scan_btn.config(state="disabled")
        self._prog.set(0)
        self._addr_by_iid.clear()
        self._dmg_write_by_iid.clear()
        for i in self._tree.get_children():
            self._tree.delete(i)
        self._status.set("Scanning MEM2...")
        threading.Thread(
            target=_run_scan,
            args=(set(self._keys), self._on_prog, self._on_done),
            kwargs={"show_unknowns": self._show_unknowns.get()},
            daemon=True,
        ).start()

    def _sort_by(self, col_id: str):
        if self._sort_col == col_id:
            self._sort_asc = not self._sort_asc
        else:
            self._sort_col = col_id
            self._sort_asc = True

        col_map = {c[0]: c[1] for c in _COLS}
        for cid, header, _, _ in _COLS:
            arrow = (" ▲" if self._sort_asc else " ▼") if cid == col_id else ""
            self._tree.heading(cid, text=col_map[cid] + arrow)

        items = [(self._tree.set(iid, col_id), iid)
                 for iid in self._tree.get_children("")]

        def sort_key(val):
            try:
                return (0, float(val))
            except Exception:
                return (1, str(val).lower())

        items.sort(key=lambda x: sort_key(x[0]), reverse=not self._sort_asc)
        for idx, (_, iid) in enumerate(items):
            self._tree.move(iid, "", idx)

    def _on_prog(self, pct: float):
        try:
            self.root.after(0, lambda: self._prog.set(pct))
        except Exception:
            pass

    def _on_done(self, hits: list):
        def _f():
            _TYPE_LABELS = {"3": "3:Linear", "4": "4:Physics",
                            3:   "3:Linear",   4: "4:Physics"}
            for h in hits:
                type_str = _TYPE_LABELS.get(h["type"], str(h["type"]))
                iid = self._tree.insert("", "end", values=(
                    f"0x{h['addr']:08X}",
                    h["key"], h["move"], h["dmg"],
                    h.get("cluster", ""),
                    h.get("super_hit_react", "?"),
                    h.get("super_life", "?"),
                    h.get("super_air_kb_y", "?"),
                    h.get("super_speed", "?"),
                    h.get("super_accel", "?"),
                    h.get("super_speed_2", "?"),
                    h.get("super_accel_b", "?"),
                    h.get("super_accel_c", "?"),
                    h.get("super_multihit_cap", "?"),
                    h.get("super_radius", "?"),
                    h["radius"], h["speed"], h["accel"],
                    h["kb_x"], h["kb_y"],
                    h["arc"], h["arc2"],
                    h.get("spawn_x", "?"), h.get("spawn_y", "?"), h["hitbox"],
                    type_str,
                    h["id"], h["lifetime"], h["hb_size"],
                    h.get("fmt", ""),
                ))
                self._addr_by_iid[iid]      = h["addr"]
                self._dmg_write_by_iid[iid] = h.get("dmg_write_addr", h["addr"] + 2)
            self._scanning = False
            self._scan_btn.config(state="normal")
            self._prog.set(100)
            n_known = sum(1 for h in hits if h.get("key") != "?")
            n_unk   = sum(1 for h in hits if h.get("key") == "?" and h.get("move") == "Unknown")
            self._status.set(
                f"Done  -  {len(hits)} match(es): {n_known} attributed, {n_unk} unknown."
            )
        try:
            self.root.after(0, _f)
        except Exception:
            pass

    def _col_index(self, event) -> int:
        col = self._tree.identify_column(event.x)
        return int(col[1:]) - 1 if col else -1

    def _fmt_for_iid(self, iid: str) -> str:
        vals = self._tree.item(iid, "values")
        return str(vals[_FMT_COL_IDX]) if len(vals) > _FMT_COL_IDX else ""

    def _on_right_click(self, event):
        iid = self._tree.identify_row(event.y)
        if not iid:
            return
        addr = self._addr_by_iid.get(iid)
        if addr is None:
            return

        col_idx     = self._col_index(event)
        field_addr  = addr
        field_label = "base"
        if 0 <= col_idx < len(_COLS):
            col_id, header, fkey, _ = _COLS[col_idx]
            vals = self._tree.item(iid, "values")
            move_name = str(vals[2]) if len(vals) > 2 else ""

            if fkey == "dmg":
                field_addr = self._dmg_write_by_iid.get(iid, addr + _dmg_write_offset(self._fmt_for_iid(iid)))
                field_label = "dmg"
            elif move_name == "Zombie Fall" and fkey == "spawn_y":
                field_addr = addr + _FRANK_ZOMBIE_FALL_SPAWN_Y_OFF
                field_label = header

            elif move_name == "Zombie Attack" and fkey == "speed":
                field_addr = addr + _FRANK_ZOMBIE_ATTACK_SPEED_A
                field_label = header
            elif move_name == "Zombie Attack" and fkey == "accel":
                field_addr = addr + _FRANK_ZOMBIE_ATTACK_ACCEL_A
                field_label = header

            elif move_name == "Zombie Attack" and fkey == "spawn_x":
                field_addr = addr + _FRANK_ZOMBIE_ATTACK_SPAWN_X
                field_label = header
            elif fkey in _SUPER_FIELD_OFFSETS and self._fmt_for_iid(iid) in ("super_struct", "super_struct_card", "super_struct_card2", "super_beam_card"):
                ex_base = _super_ex_base(addr, self._fmt_for_iid(iid))
                field_addr = ex_base + _SUPER_FIELD_OFFSETS[fkey][0]
                field_label = header
            elif fkey == "hitbox" and self._fmt_for_iid(iid) in ("super_struct", "super_struct_card", "super_struct_card2", "super_beam_card"):
                ex_base = _super_ex_base(addr, self._fmt_for_iid(iid))
                field_addr = ex_base + _SUPER_EX_OFFSETS["ex03c"]
                field_label = header
            elif fkey in _SUPER_EX_OFFSETS and self._fmt_for_iid(iid) in ("super_struct", "super_struct_card", "super_struct_card2", "super_beam_card"):
                ex_base = _super_ex_base(addr, self._fmt_for_iid(iid))
                field_addr = ex_base + _SUPER_EX_OFFSETS[fkey]
            elif move_name.startswith("Zombie Spree "):
                if fkey == "kb_y":
                    if move_name == "Zombie Spree L":
                        field_addr = addr + _FRANK_ZOMBIE_SPREE_KBY_L
                    elif move_name == "Zombie Spree M":
                        field_addr = addr + _FRANK_ZOMBIE_SPREE_KBY_M
                    else:
                        field_addr = addr + _FRANK_ZOMBIE_SPREE_KBY_H
                    field_label = header

                elif fkey == "speed":
                    if move_name == "Zombie Spree L":
                        field_addr = addr + _FRANK_ZOMBIE_SPREE_ACCEL_L
                    elif move_name == "Zombie Spree M":
                        field_addr = addr + _FRANK_ZOMBIE_SPREE_ACCEL_M
                    else:
                        field_addr = addr + _FRANK_ZOMBIE_SPREE_ACCEL_H
                    field_label = header

                elif fkey == "arc":
                    if move_name == "Zombie Spree L":
                        field_addr = addr + _FRANK_ZOMBIE_SPREE_ARC_L
                    elif move_name == "Zombie Spree M":
                        field_addr = addr + _FRANK_ZOMBIE_SPREE_ARC_M
                    else:
                        field_addr = addr + _FRANK_ZOMBIE_SPREE_ARC_H
                    field_label = header

                elif fkey and fkey in FIELD_OFFSETS:
                    field_addr  = addr + FIELD_OFFSETS[fkey]
                    field_label = header

            elif fkey and fkey in FIELD_OFFSETS:
                field_addr  = addr + FIELD_OFFSETS[fkey]
                field_label = header

        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label=f"Copy base address (0x{addr:08X})",
                         command=lambda: self._copy(f"0x{addr:08X}"))
        menu.add_command(label=f"Go to base address (0x{addr:08X})",
                         command=lambda: self._show_address_info(addr, f"Base @ 0x{addr:08X}"))
        if field_addr != addr:
            menu.add_separator()
            menu.add_command(label=f"Copy {field_label} address (0x{field_addr:08X})",
                             command=lambda: self._copy(f"0x{field_addr:08X}"))
            menu.add_command(label=f"Go to {field_label} address (0x{field_addr:08X})",
                             command=lambda: self._show_address_info(field_addr, f"{field_label} @ 0x{field_addr:08X}"))
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _copy(self, text: str):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self._status.set(f"Copied {text}")

    def _show_address_info(self, addr: int, title: str):
        if rbytes is None:
            messagebox.showerror("Address", "dolphin_io.rbytes unavailable", parent=self.root)
            return

        line_size = 16
        context_lines = 8
        line_base = addr & ~(line_size - 1)
        start = max(SCAN_START, line_base - context_lines * line_size)
        total_lines = context_lines * 2 + 1
        size = total_lines * line_size
        try:
            data = rbytes(start, size) or b""
        except Exception as e:
            messagebox.showerror("Address", f"Read failed: {e}", parent=self.root)
            return

        dlg = tk.Toplevel(self.root)
        dlg.title(title)
        dlg.geometry("780x440")

        txt = tk.Text(dlg, wrap="none", font=("Consolas", 10), bg="#101214", fg="#E8E8E8")
        txt.pack(fill="both", expand=True, padx=8, pady=8)
        txt.insert("end", "Right-click menu address view. '>>' marks the selected line.\n\n")

        current_line = (line_base - start) // line_size
        for i in range(total_lines):
            off = i * line_size
            chunk = data[off:off + line_size]
            a = start + off
            hx = " ".join(f"{b:02X}" for b in chunk)
            asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
            prefix = ">>" if i == current_line else "  "
            txt.insert("end", f"{prefix} 0x{a:08X}: {hx:<47} {asc}\n")
        txt.config(state="disabled")

    def _on_double_click(self, event):
        col_idx = self._col_index(event)
        iid     = self._tree.identify_row(event.y)
        if not iid or col_idx < 0:
            return

        col_id, header, fkey, is_float = _COLS[col_idx]
        if col_id in ("address", "char", "move", "cluster", "fmt"):
            return

        addr = self._addr_by_iid.get(iid)
        if addr is None:
            return

        fmt = self._fmt_for_iid(iid)
        vals = self._tree.item(iid, "values")
        move_name = str(vals[2]) if len(vals) > 2 else ""

        if fkey == "dmg":
            write_addr = self._dmg_write_by_iid.get(iid, addr + _dmg_write_offset(fmt))
        elif move_name == "Zombie Fall" and fkey == "spawn_y":
            write_addr = addr + _FRANK_ZOMBIE_FALL_SPAWN_Y_OFF
        elif move_name == "Zombie Attack" and fkey == "speed":
            write_addr = addr + _FRANK_ZOMBIE_ATTACK_SPEED_A
        elif fkey == "hitbox" and fmt in ("super_struct", "super_struct_card", "super_struct_card2", "super_beam_card"):
            ex_base = _super_ex_base(addr, fmt)
            write_addr = ex_base + _SUPER_EX_OFFSETS["ex03c"]
        elif fkey in _SUPER_EX_OFFSETS and fmt in ("super_struct", "super_struct_card", "super_struct_card2", "super_beam_card"):
            ex_base = _super_ex_base(addr, fmt)
            write_addr = ex_base + _SUPER_EX_OFFSETS[fkey]
        elif move_name == "Zombie Attack" and fkey == "accel":
            write_addr = addr + _FRANK_ZOMBIE_ATTACK_ACCEL_A

        elif move_name == "Zombie Attack" and fkey == "spawn_x":
            write_addr = addr + _FRANK_ZOMBIE_ATTACK_SPAWN_X
        elif fkey in _SUPER_FIELD_OFFSETS and fmt in ("super_struct", "super_struct_card", "super_struct_card2", "super_beam_card"):
            ex_base = _super_ex_base(addr, fmt)
            write_addr = ex_base + _SUPER_FIELD_OFFSETS[fkey][0]
        elif move_name.startswith("Zombie Spree "):
            if fkey == "kb_y":
                if move_name == "Zombie Spree L":
                    write_addr = addr + _FRANK_ZOMBIE_SPREE_KBY_L
                elif move_name == "Zombie Spree M":
                    write_addr = addr + _FRANK_ZOMBIE_SPREE_KBY_M
                else:
                    write_addr = addr + _FRANK_ZOMBIE_SPREE_KBY_H

            elif fkey == "speed":
                if move_name == "Zombie Spree L":
                    write_addr = addr + _FRANK_ZOMBIE_SPREE_ACCEL_L
                elif move_name == "Zombie Spree M":
                    write_addr = addr + _FRANK_ZOMBIE_SPREE_ACCEL_M
                else:
                    write_addr = addr + _FRANK_ZOMBIE_SPREE_ACCEL_H

            elif fkey == "arc":
                if move_name == "Zombie Spree L":
                    write_addr = addr + _FRANK_ZOMBIE_SPREE_ARC_L
                elif move_name == "Zombie Spree M":
                    write_addr = addr + _FRANK_ZOMBIE_SPREE_ARC_M
                else:
                    write_addr = addr + _FRANK_ZOMBIE_SPREE_ARC_H

            elif fkey in FIELD_OFFSETS:
                write_addr = addr + FIELD_OFFSETS[fkey]
            else:
                return
            
        elif fkey in FIELD_OFFSETS:
            write_addr = addr + FIELD_OFFSETS[fkey]
        else:
            return

        vals    = self._tree.item(iid, "values")
        cur_val = vals[col_idx]

        new_val = simpledialog.askstring(
            f"Edit {header}",
            f"Move: {vals[2]}\nAddress: 0x{write_addr:08X}\nCurrent: {cur_val}\n\nNew value:",
            parent=self.root, initialvalue=str(cur_val),
        )
        if new_val is None:
            return
        new_val = new_val.strip()

        super_field_type = None
        if fkey in _SUPER_FIELD_OFFSETS:
            super_field_type = _SUPER_FIELD_OFFSETS[fkey][1]

        if is_float:
            try:
                fval = float(new_val)
            except ValueError:
                messagebox.showerror("Invalid", f"'{new_val}' is not a valid float.",
                                     parent=self.root)
                return
            if _write_f32(write_addr, fval):
                self._tree.set(iid, col_id, f"{fval:.4f}")
                self._status.set(f"Wrote {fval} to 0x{write_addr:08X}")
            else:
                messagebox.showerror("Write failed", "Could not write to Dolphin.",
                                     parent=self.root)
        else:
            try:
                ival = int(new_val, 16) if new_val.startswith("0x") else int(new_val)
            except ValueError:
                messagebox.showerror("Invalid", f"'{new_val}' is not a valid number.",
                                     parent=self.root)
                return
            if fkey == "dmg":
                if not (0 <= ival <= 0xFFFFFFFF):
                    messagebox.showerror("Out of range", "Damage must be 0–4294967295.",
                                         parent=self.root)
                    return
            else:
                if fkey == "spawn_x":
                    if not (0 <= ival <= 0xFF):
                        messagebox.showerror("Out of range", "Spawn X must be 0–255.",
                                             parent=self.root)
                        return
                elif super_field_type == "u32":
                    if not (0 <= ival <= 0xFFFFFFFF):
                        messagebox.showerror("Out of range", "Value must be 0–4294967295.",
                                             parent=self.root)
                        return
                elif not (0 <= ival <= 0xFFFF):
                    messagebox.showerror("Out of range", "Value must be 0–65535.",
                                         parent=self.root)
                    return

            if fkey == "dmg":
                resolved = self._dmg_write_by_iid.get(iid)
                fallback = addr + _dmg_write_offset(fmt)

                if fmt == "super_beam_card" and resolved is not None:
                    ok = _write_u32(resolved, ival)
                elif fmt in ("super_struct", "super_struct_card", "super_struct_card2") and resolved is not None:
                    if not (0 <= ival <= 0xFFFF):
                        messagebox.showerror("Out of range", "Damage must be 0–65535.",
                                            parent=self.root)
                        return
                    ok = _write_u16(resolved, ival)

                elif resolved and resolved != fallback:
                    ok = _write_u32(resolved, ival)

                else:
                    ok = _write_dmg(addr, ival, fmt)
            elif fkey == "spawn_x":
                ok = bool(wbytes(write_addr, bytes([ival]))) if wbytes is not None else False
            elif super_field_type == "u32":
                ok = _write_u32(write_addr, ival)
            else:
                ok = _write_u16(write_addr, ival)
            if ok:
                self._tree.set(iid, col_id, ival)
                self._status.set(f"Wrote {ival} to 0x{write_addr:08X}")
            else:
                messagebox.showerror("Write failed", "Could not write to Dolphin.",
                                     parent=self.root)


# ---------------------------------------------------------------------------
_inst = None

def open_proj_scanner_window(get_active_fn):
    def _c(master):
        global _inst
        if _inst:
            try:
                _inst.root.lift()
                return
            except Exception:
                pass
        _inst = ProjScannerWindow(master, get_active_fn)
    tk_call(_c)