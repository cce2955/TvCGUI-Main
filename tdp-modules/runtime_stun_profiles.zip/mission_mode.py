from __future__ import annotations

import json
import os
import sys
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


def _bundle_base_dir() -> str:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


def _user_data_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


MISSIONS_DIR = os.path.join(_bundle_base_dir(), "missions")
MISSION_PROGRESS_FILE = os.path.join(_user_data_dir(), "mission_progress.json")


@dataclass
class MissionStep:
    labels: List[str]
    grace: int = 0
    pass_step: bool = False
    grace_keeps_alive_only: bool = False
    display: str = ""


@dataclass
class MissionDef:
    mission_id: str
    name: str
    character: str
    steps: List[MissionStep] = field(default_factory=list)
    notes: str = ""
    setup_debug_flags: Dict[str, int] = field(default_factory=dict)
    setup_megacrash_trainer: Dict[str, Any] = field(default_factory=dict)
    goal: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MissionPack:
    character: str
    missions: List[MissionDef] = field(default_factory=list)


def _safe_slug(value: str) -> str:
    return "".join(ch.lower() if ch.isalnum() else "_" for ch in value).strip("_")


def _missions_path_for_character(character_name: str) -> str:
    slug = _safe_slug(character_name)
    return os.path.join(MISSIONS_DIR, f"{slug}.json")


def _load_json_file(path: str, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _save_json_file(path: str, payload: Any) -> None:
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def load_mission_pack(character_name: str) -> MissionPack:
    path = _missions_path_for_character(character_name)
    raw = _load_json_file(path, default=None)

    if not isinstance(raw, dict):
        return MissionPack(character=character_name, missions=[])

    missions: List[MissionDef] = []
    raw_missions = raw.get("missions", [])

    for entry in raw_missions:
        if not isinstance(entry, dict):
            continue

        mission_id = str(entry.get("mission_id", "")).strip()
        name = str(entry.get("name", mission_id)).strip()
        notes = str(entry.get("notes", "")).strip()

        setup_debug_flags: Dict[str, int] = {}
        raw_setup_debug_flags = entry.get("setup_debug_flags", {})
        if isinstance(raw_setup_debug_flags, dict):
            for key, value in raw_setup_debug_flags.items():
                try:
                    setup_debug_flags[str(key)] = int(value)
                except Exception:
                    pass

        setup_megacrash_trainer: Dict[str, Any] = {}
        raw_setup_mega = (
            entry.get("setup_megacrash_trainer")
            or entry.get("setup_megacrash")
            or entry.get("megacrash_trainer")
            or {}
        )
        if isinstance(raw_setup_mega, dict):
            # Keep values raw-ish here; main.py owns validation/clamping so
            # the mission JSON can use strings like "targeted" or "5C".
            setup_megacrash_trainer = dict(raw_setup_mega)

        goal: Dict[str, Any] = {}
        raw_goal = entry.get("goal", {})
        if isinstance(raw_goal, dict):
            goal = dict(raw_goal)

        steps: List[MissionStep] = []
        for step in entry.get("steps", []):
            if not isinstance(step, dict):
                continue

            labels: List[str] = []
            raw_labels = step.get("labels")

            if isinstance(raw_labels, list):
                for item in raw_labels:
                    text = str(item).strip()
                    if text:
                        labels.append(text)

            if not labels:
                label = str(step.get("label", "")).strip()
                if label:
                    labels.append(label)

            if not labels:
                continue

            grace = 0
            try:
                grace = max(0, int(step.get("grace", 0) or 0))
            except Exception:
                grace = 0

            pass_step = bool(step.get("pass", False))
            display = str(
                step.get("display")
                or step.get("display_label")
                or step.get("text")
                or ""
            ).strip()

            steps.append(
                MissionStep(
                    labels=labels,
                    grace=grace,
                    pass_step=pass_step,
                    grace_keeps_alive_only=bool(
                        step.get("grace_keeps_alive_only", False)
                    ),
                    display=display,
                )
            )
        if not mission_id or (not steps and not goal):
            continue

        missions.append(
            MissionDef(
                mission_id=mission_id,
                name=name,
                character=character_name,
                steps=steps,
                notes=notes,
                setup_debug_flags=setup_debug_flags,
                setup_megacrash_trainer=setup_megacrash_trainer,
                goal=goal,
            )
        )

    return MissionPack(character=character_name, missions=missions)


def load_progress() -> Dict[str, Any]:
    data = _load_json_file(MISSION_PROGRESS_FILE, default={})
    if not isinstance(data, dict):
        return {}
    return data


def save_progress(progress: Dict[str, Any]) -> None:
    _save_json_file(MISSION_PROGRESS_FILE, progress)


def _get_char_progress_node(progress: Dict[str, Any], character_name: str) -> Dict[str, Any]:
    char_key = _safe_slug(character_name)
    node = progress.get(char_key)

    if not isinstance(node, dict):
        node = {}

    completed = node.get("completed")
    if not isinstance(completed, dict):
        legacy_completed = {
            k: v for k, v in node.items()
            if isinstance(k, str) and k != "selected_mission_id"
        }
        completed = legacy_completed

    return {
        "completed": completed,
        "selected_mission_id": node.get("selected_mission_id"),
    }


def _set_char_progress_node(progress: Dict[str, Any], character_name: str, node: Dict[str, Any]) -> Dict[str, Any]:
    char_key = _safe_slug(character_name)
    progress[char_key] = {
        "completed": dict(node.get("completed", {})),
        "selected_mission_id": node.get("selected_mission_id"),
    }
    return progress


def is_mission_complete(progress: Dict[str, Any], character_name: str, mission_id: str) -> bool:
    node = _get_char_progress_node(progress, character_name)
    completed = node.get("completed", {})
    return bool(completed.get(mission_id, False))


def mark_mission_complete(progress: Dict[str, Any], character_name: str, mission_id: str) -> Dict[str, Any]:
    node = _get_char_progress_node(progress, character_name)
    completed = dict(node.get("completed", {}))
    completed[mission_id] = True
    node["completed"] = completed
    return _set_char_progress_node(progress, character_name, node)


def get_selected_mission_id(progress: Dict[str, Any], character_name: str) -> Optional[str]:
    node = _get_char_progress_node(progress, character_name)
    mission_id = node.get("selected_mission_id")
    return str(mission_id).strip() if mission_id else None


def set_selected_mission_id(progress: Dict[str, Any], character_name: str, mission_id: Optional[str]) -> Dict[str, Any]:
    node = _get_char_progress_node(progress, character_name)
    node["selected_mission_id"] = mission_id
    return _set_char_progress_node(progress, character_name, node)


def find_mission_by_id(pack: MissionPack, mission_id: Optional[str]) -> Optional[MissionDef]:
    if not mission_id:
        return None
    for mission in pack.missions:
        if mission.mission_id == mission_id:
            return mission
    return None


def pick_default_mission(pack: MissionPack, progress: Dict[str, Any]) -> Optional[MissionDef]:
    if not pack.missions:
        return None

    selected_id = get_selected_mission_id(progress, pack.character)
    selected = find_mission_by_id(pack, selected_id)
    if selected is not None:
        return selected

    for mission in pack.missions:
        if not is_mission_complete(progress, pack.character, mission.mission_id):
            return mission

    return pack.missions[0]


def _goal_to_step_labels(goal: Dict[str, Any]) -> List[List[str]]:
    if not isinstance(goal, dict):
        return []

    goal_type = str(goal.get("type", "")).strip().lower()

    if goal_type == "state_duration":
        target_state = str(goal.get("target_state", "")).strip()
        frames = int(goal.get("frames", 0) or 0)
        if target_state and frames > 0:
            return [[f"{target_state} for {frames} frames"]]

    if goal_type == "damage_under_hits":
        damage = int(goal.get("damage", 0) or 0)
        max_hits = int(goal.get("max_hits", 0) or 0)
        if damage > 0 and max_hits > 0:
            return [[f"{damage} damage in {max_hits} hits or less"]]

    if goal_type == "combo_damage":
        damage = int(goal.get("damage", 0) or 0)
        if damage > 0:
            return [[f"{damage} damage in a single combo"]]

    return [["Special challenge"]]

_STEP_BTN_RE = re.compile(
    r"(?:^[0-9]+([ABCLMH])(?:$|\s|\(|\))|^j\.?([ABCLMH])(?:$|\s|\(|\))|(?:^|\s)([ABCLMH])(?:$|\s|\(|\)))",
    re.I,
)

def _step_color(labels: List[str]) -> Optional[str]:
    text = " / ".join(str(x).strip() for x in (labels or []) if str(x).strip())
    if not text:
        return None

    m = _STEP_BTN_RE.search(text)
    if not m:
        return None

    btn = next(g for g in m.groups() if g).upper()

    if btn in {"A", "L"}:
        return "blue"
    if btn in {"B", "M"}:
        return "yellow"
    if btn in {"C", "H"}:
        return "green"

    return None
def build_overlay_payload(character_name: str) -> Dict[str, Any]:
    pack = load_mission_pack(character_name)
    progress = load_progress()
    active = pick_default_mission(pack, progress)
    selected_id = get_selected_mission_id(progress, pack.character)

    return {
        "character": pack.character,
        "mission_count": len(pack.missions),
        "active_mission_id": active.mission_id if active else None,
        "active_mission_name": active.name if active else None,
        "active_mission_notes": active.notes if active else "",
        "active_mission_steps": (
            [
{
    "labels": step.labels,
    "display": step.display,
    "grace": step.grace,
    "pass": step.pass_step,
    "grace_keeps_alive_only": step.grace_keeps_alive_only,
    "color": _step_color(step.labels),
}
    for step in active.steps
]
            if active and active.steps
            else _goal_to_step_labels(active.goal) if active else []
        ),
        "active_mission_goal": dict(active.goal) if active else {},
        "active_mission_setup_debug_flags": dict(active.setup_debug_flags) if active else {},
        "active_mission_setup_megacrash_trainer": dict(active.setup_megacrash_trainer) if active else {},
        "selected_mission_id": selected_id,
        "missions": [
            {
                "mission_id": mission.mission_id,
                "name": mission.name,
                "notes": mission.notes,
                "completed": is_mission_complete(progress, pack.character, mission.mission_id),
                "selected": mission.mission_id == selected_id,
                "steps": [
{
    "labels": step.labels,
    "display": step.display,
    "grace": step.grace,
    "pass": step.pass_step,
    "grace_keeps_alive_only": step.grace_keeps_alive_only,
    "color": _step_color(step.labels),
}
    for step in mission.steps
] if mission.steps else _goal_to_step_labels(mission.goal),
                "goal": dict(mission.goal),
                "setup_debug_flags": dict(mission.setup_debug_flags),
                "setup_megacrash_trainer": dict(mission.setup_megacrash_trainer),
            }
            for mission in pack.missions
        ],
    }