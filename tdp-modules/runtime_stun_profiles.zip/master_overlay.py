#!/usr/bin/env python3
"""
master_overlay.py
-----------------
Single Dolphin-parented transparent overlay window that will eventually host:
- HUD drawing
- hitbox drawing
- projectile drawing
- debug overlays

For now, this is the master shell only:
- one pygame window
- one Dolphin sync loop
- one event loop
- one flip per frame
- simple toggles for HUD / hitboxes
- optional control file so another process can toggle behavior later

This file is intentionally the first step only.
"""

from __future__ import annotations

import ctypes
import json
import os
import sys
import time
import traceback
from dataclasses import dataclass
from typing import Optional, Protocol

import pygame
import win32con
import win32gui


TARGET_FPS = 60
COLORKEY = (0, 0, 0)

BASE_W = 1280
BASE_H = 720

MASTER_CONTROL_FILE = "master_overlay_control.json"
MISSION_MODE_FILE = "mission_mode_state.json"
MISSION_OVERLAY_FILE = "mission_overlay_data.json"
MISSION_SELECT_FILE = "mission_select_command.json"
MISSION_CELEBRATE_ACK_FILE = "mission_celebrate_ack.json"
CRASH_LOG_FILE = "master_overlay_crash.log"

def pause_on_error(context: str, exc: BaseException) -> None:
    print(f"\n[{context}]")
    print(f"error={exc!r}")
    traceback.print_exc()
    try:
        with open(CRASH_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"\n[{context}]\n")
            f.write(f"error={exc!r}\n")
            traceback.print_exc(file=f)
            f.write("\n")
    except Exception:
        pass

    try:
        input("\nCrash detected. Press Enter to close...")
    except EOFError:
        pass


def set_dpi_aware() -> None:
    try:
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def find_dolphin_hwnd() -> Optional[int]:
    candidates: list[tuple[int, int, str]] = []

    def score_title(title: str) -> int:
        tl = title.lower()
        if "dolphin" not in tl:
            return -10_000

        score = 0

        if "|" in title:
            score += 50
            score += min(30, title.count("|") * 5)

        for token in ("jit", "jit64", "opengl", "vulkan", "d3d", "direct3d", "hle"):
            if token in tl:
                score += 20

        if "(" in title and ")" in title:
            score += 30

        for bad in (
            "memory",
            "watch",
            "log",
            "breakpoint",
            "register",
            "disassembly",
            "config",
            "settings",
        ):
            if bad in tl:
                score -= 25

        if title.count("|") >= 3:
            score += 20

        return score

    def cb(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd):
            return
        title = win32gui.GetWindowText(hwnd) or ""
        if not title:
            return
        if "dolphin" not in title.lower():
            return
        candidates.append((score_title(title), hwnd, title))

    win32gui.EnumWindows(cb, None)

    if not candidates:
        return None

    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1]


def is_valid_hwnd(hwnd: Optional[int]) -> bool:
    try:
        return bool(hwnd and win32gui.IsWindow(int(hwnd)))
    except Exception:
        return False


def get_client_screen_rect(hwnd: Optional[int]) -> Optional[tuple[int, int, int, int]]:
    if not is_valid_hwnd(hwnd):
        return None

    try:
        left, top, right, bottom = win32gui.GetClientRect(int(hwnd))
        tl = win32gui.ClientToScreen(int(hwnd), (left, top))
        br = win32gui.ClientToScreen(int(hwnd), (right, bottom))
    except Exception:
        return None

    w = br[0] - tl[0]
    h = br[1] - tl[1]
    if w <= 0 or h <= 0:
        return None

    return tl[0], tl[1], w, h


def apply_overlay_style(hwnd: int) -> None:
    style = win32gui.GetWindowLong(hwnd, win32con.GWL_STYLE)
    style &= ~(
        win32con.WS_CAPTION
        | win32con.WS_THICKFRAME
        | win32con.WS_MINIMIZE
        | win32con.WS_MAXIMIZE
        | win32con.WS_SYSMENU
    )
    style |= win32con.WS_POPUP
    win32gui.SetWindowLong(hwnd, win32con.GWL_STYLE, style)

    ex = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
    ex |= win32con.WS_EX_LAYERED
    ex &= ~win32con.WS_EX_TOPMOST
    win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, ex)

    win32gui.SetLayeredWindowAttributes(hwnd, 0x000000, 0, win32con.LWA_COLORKEY)
    win32gui.SetWindowPos(
        hwnd,
        win32con.HWND_NOTOPMOST,
        0,
        0,
        0,
        0,
        win32con.SWP_FRAMECHANGED
        | win32con.SWP_NOMOVE
        | win32con.SWP_NOSIZE
        | win32con.SWP_NOACTIVATE,
    )


def sync_overlay_to_dolphin(dolphin_hwnd: Optional[int], overlay_hwnd: Optional[int]) -> Optional[tuple[int, int]]:
    if not is_valid_hwnd(overlay_hwnd):
        return None

    rect = get_client_screen_rect(dolphin_hwnd)
    if rect is None:
        return None

    x, y, w, h = rect
    try:
        win32gui.SetWindowPos(
            int(overlay_hwnd),
            win32con.HWND_NOTOPMOST,
            x,
            y,
            w,
            h,
            win32con.SWP_NOACTIVATE,
        )
    except Exception:
        return None

    return w, h


@dataclass
class MasterControl:
    show_hud: bool = True
    show_hitboxes: bool = True
    show_hurtboxes: bool = True
    show_debug: bool = False


class Renderer(Protocol):
    def on_resize(self, w: int, h: int) -> None:
        ...

    def update(self, dt: float, control: MasterControl) -> None:
        ...

    def draw(self, screen: pygame.Surface, control: MasterControl) -> None:
        ...


class NullHudRenderer:
    """
    Placeholder HUD renderer.
    This will get replaced by the converted HUD module later.
    """

    def __init__(self) -> None:
        self.font: Optional[pygame.font.Font] = None
        self.smallfont: Optional[pygame.font.Font] = None
        self.w = BASE_W
        self.h = BASE_H

    def on_resize(self, w: int, h: int) -> None:
        self.w = w
        self.h = h
        scale = min(w / BASE_W, h / BASE_H)
        font_size = max(10, int(16 * scale))
        small_size = max(8, int(13 * scale))

        try:
            self.font = pygame.font.SysFont("consolas", font_size, bold=True)
        except Exception:
            self.font = pygame.font.Font(None, font_size)

        try:
            self.smallfont = pygame.font.SysFont("consolas", small_size)
        except Exception:
            self.smallfont = pygame.font.Font(None, small_size)

    def update(self, dt: float, control: MasterControl) -> None:
        return

    def draw(self, screen: pygame.Surface, control: MasterControl) -> None:
        if not control.show_hud:
            return
        if self.font is None or self.smallfont is None:
            return

        label = self.font.render("MASTER HUD SLOT", True, (220, 220, 220))
        sub = self.smallfont.render("HUD renderer not wired yet", True, (150, 150, 150))

        x = 24
        y = max(50, int(screen.get_height() * 0.22))

        bg_w = max(label.get_width(), sub.get_width()) + 16
        bg_h = label.get_height() + sub.get_height() + 14

        bg = pygame.Surface((bg_w, bg_h), pygame.SRCALPHA)
        bg.fill((18, 18, 18, 180))
        screen.blit(bg, (x - 8, y - 6))

        screen.blit(label, (x, y))
        screen.blit(sub, (x, y + label.get_height() + 4))


class NullHitboxRenderer:
    """
    Placeholder hitbox renderer.
    This will get replaced by the converted hitbox module later.
    """

    def __init__(self) -> None:
        self.w = BASE_W
        self.h = BASE_H
        self.phase = 0.0

    def on_resize(self, w: int, h: int) -> None:
        self.w = w
        self.h = h

    def update(self, dt: float, control: MasterControl) -> None:
        self.phase += dt * 2.0

    def draw(self, screen: pygame.Surface, control: MasterControl) -> None:
        if not control.show_hitboxes:
            return

        cx = screen.get_width() // 2
        cy = screen.get_height() // 2
        pulse = 40 + int(10 * (0.5 + 0.5 * __import__("math").sin(self.phase)))
        r = max(20, pulse)

        pygame.draw.circle(screen, (255, 120, 120, 100), (cx, cy), r, 2)
        pygame.draw.circle(screen, (120, 180, 255, 100), (cx + 80, cy - 20), max(12, r - 18), 2)
        pygame.draw.line(screen, (200, 200, 200, 120), (cx - 10, cy), (cx + 10, cy), 1)
        pygame.draw.line(screen, (200, 200, 200, 120), (cx, cy - 10), (cx, cy + 10), 1)


class MasterOverlay:
    def __init__(self) -> None:
        self.dolphin_hwnd: Optional[int] = None
        self.overlay_hwnd: Optional[int] = None
        self.screen: Optional[pygame.Surface] = None
        self.clock: Optional[pygame.time.Clock] = None

        self.w = BASE_W
        self.h = BASE_H

        self.running = True
        self.control = MasterControl()

        self.font: Optional[pygame.font.Font] = None
        self.smallfont: Optional[pygame.font.Font] = None

        self._last_control_mtime = 0.0
        
        self.mission_active = False
        self.mission_slot: Optional[str] = None
        self._last_mission_mtime = 0.0
        self._last_mission_overlay_mtime = 0.0
        self.mission_overlay_data: dict = {}
        self.mission_click_rects: list[tuple[pygame.Rect, Optional[str]]] = []
        self.mission_panel_rect: Optional[pygame.Rect] = None
        self.mission_toggle_rect: Optional[pygame.Rect] = None
        self.mission_hint_rect: Optional[pygame.Rect] = None
        self.mission_show_all: bool = False
        self.mission_show_hint: bool = False

        self.hud_renderer: Renderer = NullHudRenderer()
        self.hitbox_renderer: Renderer = NullHitboxRenderer()

        # Mission step animation state
        # step_anim[idx] = t in [0.0, 1.0]  (1.0 = fully active/metallic, 0.0 = dark/done)
        self.step_anim: dict[int, float] = {}
        self._prev_current_step: int = -1
        self._prev_completed_count: int = 0
        self._prev_live_completed_count: int = 0
        self._prev_live_step_total: int = 0
        self._prev_live_mission_id: str = ""
        self._last_clear_seq_seen: int = 0

        # Celebration state
        self._celebrate_active: bool = False
        self._celebrate_phase: float = 0.0      # total elapsed since trigger
        self._celebrate_particles: list = []
        self._prev_mission_complete: bool = False
        self._last_mission_id_seen: str = ""
        self._mission_hold_frames: int = 0
        self._mission_hold_data: dict = {}
        self._mission_hold_duration_frames: int = 120

        # Lightweight mission polish state
        self._toast_phase: float = 0.0
        self._row_bump: dict[int, float] = {}
        self._last_completed_for_bump: int = 0
        

    def init(self) -> None:
        set_dpi_aware()

        # Hook Dolphin memory before anything tries to read it
        from dolphin_io import hook
        hook()

        self.dolphin_hwnd = find_dolphin_hwnd()

        self.dolphin_hwnd = find_dolphin_hwnd()
        if not self.dolphin_hwnd:
            raise RuntimeError("Dolphin window not found.")

        pygame.init()

        try:
            from hud_overlay import HudRenderer
            self.hud_renderer = HudRenderer()
            print("[master] hud renderer loaded")
        except Exception:
            print("[master] failed to import hud renderer")
            traceback.print_exc()
            self.hud_renderer = NullHudRenderer()

        try:
            from hitboxesscaling import HitboxRenderer
            self.hitbox_renderer = HitboxRenderer()
            print("[master] hitbox renderer loaded")
        except Exception:
            print("[master] failed to import hitbox renderer")
            traceback.print_exc()
            self.hitbox_renderer = NullHitboxRenderer()

        self.screen = pygame.display.set_mode((self.w, self.h), pygame.SRCALPHA)
        pygame.display.set_caption("TvC Master Overlay")

        icon_path = os.path.join("assets", "portraits", "Placeholder.png")
        if not os.path.exists(icon_path):
            icon_path = os.path.join("assets", "icon.png")
        if os.path.exists(icon_path):
            try:
                icon = pygame.image.load(icon_path).convert_alpha()
                pygame.display.set_icon(icon)
            except Exception:
                pass

        self.overlay_hwnd = pygame.display.get_wm_info()["window"]
        apply_overlay_style(self.overlay_hwnd)
        win32gui.SetWindowLong(self.overlay_hwnd, win32con.GWL_HWNDPARENT, self.dolphin_hwnd)

        self.clock = pygame.time.Clock()

        self._refresh_fonts()
        self.hud_renderer.on_resize(self.w, self.h)
        self.hitbox_renderer.on_resize(self.w, self.h)

        self._write_default_control_file()

    def _refresh_fonts(self) -> None:
        scale = min(self.w / BASE_W, self.h / BASE_H)
        font_size = max(10, int(14 * scale))
        small_size = max(8, int(12 * scale))

        try:
            self.font = pygame.font.SysFont("consolas", font_size, bold=True)
        except Exception:
            self.font = pygame.font.Font(None, font_size)

        try:
            self.smallfont = pygame.font.SysFont("consolas", small_size)
        except Exception:
            self.smallfont = pygame.font.Font(None, small_size)
    def _char_theme_color(self, character: str) -> tuple[int, int, int]:
        name = (character or "").strip().lower()

        if "alex" in name:
            return (40, 120, 255)      # Capcom blue
        if "ryu" in name:
            return (170, 30, 30)       # deep red
        if "chun" in name:
            return (80, 150, 255)      # Chun blue
        if "ken" in name:
            return (245, 245, 245)     # white
        if "jun" in name:
            return (255, 70, 170)      # hot pink
        if "viewtiful joe" in name or "v joe" in name or "joe" in name:
            return (220, 40, 40)       # hero red
        if "casshan" in name:
            return (180, 230, 255)     # steel/cyan
        if "doronjo" in name:
            return (210, 120, 255)     # villain purple
        if "saki" in name:
            return (255, 220, 80)      # gold
        if "batsu" in name:
            return (255, 140, 40)      # orange
        if "morrigan" in name:
            return (120, 40, 170)      # succubus purple
        if "roll" in name:
            return (255, 170, 210)     # soft pink
        if "polimar" in name:
            return (220, 35, 35)       # red hero
        if "karas" in name:
            return (90, 90, 110)       # dark steel
        if "zero" in name:
            return (220, 40, 40)       # crimson
        if "gold_lightan" in name or "gold lightan" in name:
            return (255, 215, 40)      # gold
        if "tekkaman_blade" in name or "tekkaman blade" in name:
            return (120, 180, 255)     # blade blue
        if "tekkaman" in name:
            return (235, 235, 235)     # white armor
        if "volnutt" in name:
            return (70, 170, 255)      # mega blue
        if "ptx_40a" in name or "ptx" in name:
            return (255, 150, 60)
        if "yatterman_1" in name:
            return (255, 60, 60)       # red
        if "yatterman_2" in name:
            return (255, 120, 190)     # pink

        return (170, 120, 255)
    def _wrap_text_lines(self, text: str, font: pygame.font.Font, max_width: int) -> list[str]:
        if not text:
            return []

        out: list[str] = []
        max_width = max(32, int(max_width))

        for paragraph in str(text).splitlines():
            paragraph = paragraph.strip()
            if not paragraph:
                continue

            words = paragraph.split()
            if not words:
                continue

            line = words[0]
            for word in words[1:]:
                trial = f"{line} {word}"
                if font.size(trial)[0] <= max_width:
                    line = trial
                else:
                    out.append(line)
                    line = word
            out.append(line)

        return out

    def _write_default_control_file(self) -> None:
        if os.path.exists(MASTER_CONTROL_FILE):
            return
        self._write_control_file()

    def _write_control_file(self) -> None:
        payload = {
            "show_hud": self.control.show_hud,
            "show_hitboxes": self.control.show_hitboxes,
            "show_hurtboxes": self.control.show_hurtboxes,
            "show_debug": self.control.show_debug,
        }
        try:
            with open(MASTER_CONTROL_FILE, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
        except Exception:
            pass

    def _read_control_file(self) -> None:
        try:
            mt = os.path.getmtime(MASTER_CONTROL_FILE)
            if mt == self._last_control_mtime:
                return
            self._last_control_mtime = mt

            with open(MASTER_CONTROL_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)

            self.control.show_hud = bool(data.get("show_hud", True))
            self.control.show_hitboxes = bool(data.get("show_hitboxes", True))
            self.control.show_hurtboxes = bool(data.get("show_hurtboxes", True))
            self.control.show_debug = bool(data.get("show_debug", False))
        except Exception:
            pass
    def _read_control_file(self) -> None:
            try:
                mt = os.path.getmtime(MASTER_CONTROL_FILE)
                if mt == self._last_control_mtime:
                    return
                self._last_control_mtime = mt

                with open(MASTER_CONTROL_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)

                self.control.show_hud = bool(data.get("show_hud", True))
                self.control.show_hitboxes = bool(data.get("show_hitboxes", True))
                self.control.show_debug = bool(data.get("show_debug", False))
            except Exception:
                pass

    def _read_mission_mode_file(self) -> None:
        try:
            mt = os.path.getmtime(MISSION_MODE_FILE)
            if mt == self._last_mission_mtime:
                return
            self._last_mission_mtime = mt

            with open(MISSION_MODE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)

            self.mission_active = bool(data.get("active", False))
            self.mission_slot = data.get("slot")
        except Exception:
            self.mission_active = False
            self.mission_slot = None

    def _read_mission_overlay_file(self) -> None:
        try:
            with open(MISSION_OVERLAY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)

            if not isinstance(data, dict):
                return

            self.mission_overlay_data = data

        except Exception:
            pass

    def on_resize(self, w: int, h: int) -> None:
        if w <= 0 or h <= 0:
            return
        if w == self.w and h == self.h:
            return

        self.w = w
        self.h = h

        self.screen = pygame.display.set_mode((w, h), pygame.SRCALPHA)
        self._refresh_fonts()

        self.hud_renderer.on_resize(w, h)
        self.hitbox_renderer.on_resize(w, h)

    def _write_mission_select_command(self, payload: dict) -> None:
        try:
            with open(MISSION_SELECT_FILE, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
        except Exception:
            pass
    def _write_mission_celebrate_ack(self, celebrate_token: int) -> None:
        try:
            with open(MISSION_CELEBRATE_ACK_FILE, "w", encoding="utf-8") as f:
                json.dump({"celebrate_token": int(celebrate_token)}, f, indent=2)
        except Exception:
            pass
    def handle_events(self) -> None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.mission_toggle_rect and self.mission_toggle_rect.collidepoint(event.pos):
                    self.mission_show_all = not self.mission_show_all
                    return

                if self.mission_hint_rect and self.mission_hint_rect.collidepoint(event.pos):
                    self.mission_show_hint = not self.mission_show_hint
                    return

                if self.mission_panel_rect and self.mission_panel_rect.collidepoint(event.pos):
                    for rect, mission_id in self.mission_click_rects:
                        if rect.collidepoint(event.pos):
                            if mission_id:
                                self._write_mission_select_command({
                                    "action": "select",
                                    "slot": self.mission_slot,
                                    "mission_id": mission_id,
                                })
                            return
                elif self.mission_overlay_data.get("selector_open"):
                    self._write_mission_select_command({
                        "action": "close",
                    })
                    return

            # Keyboard hotkeys intentionally disabled; layer controls live in the main GUI.

    def clear(self) -> None:
        assert self.screen is not None
        self.screen.fill(COLORKEY)

    def draw_master_debug(self, dt: float) -> None:
        if not self.control.show_debug:
            return
        if self.screen is None or self.font is None or self.smallfont is None:
            return

        lines = [
            "MASTER OVERLAY",
            f"{self.w}x{self.h}",
            f"HUD: {'ON' if self.control.show_hud else 'OFF'}",
            f"HITBOXES: {'ON' if self.control.show_hitboxes else 'OFF'}",
            f"HURTBOXES: {'ON' if self.control.show_hurtboxes else 'OFF'}",
            f"dt={dt:.4f}",
        ]

        rendered = [self.smallfont.render(line, True, (180, 180, 180)) for line in lines]
        box_w = max(s.get_width() for s in rendered) + 12
        box_h = sum(s.get_height() for s in rendered) + 12

        bg = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        bg.fill((16, 16, 16, 190))
        self.screen.blit(bg, (10, 10))

        y = 16
        for surf in rendered:
            self.screen.blit(surf, (16, y))
            y += surf.get_height()


        y = 16
        for surf in rendered:
            self.screen.blit(surf, (16, y))
            y += surf.get_height()
    def _spawn_lightning_bolt(self) -> None:
        import math, random

        # Origin: random edge or top region
        side = random.choice(["top", "left", "right"])
        if side == "top":
            ox = random.randint(int(self.w * 0.1), int(self.w * 0.9))
            oy = random.randint(0, int(self.h * 0.15))
        elif side == "left":
            ox = random.randint(0, int(self.w * 0.15))
            oy = random.randint(0, int(self.h * 0.6))
        else:
            ox = random.randint(int(self.w * 0.85), self.w)
            oy = random.randint(0, int(self.h * 0.6))

        # Target: toward center-ish with some spread
        tx = self.w // 2 + random.randint(-int(self.w * 0.25), int(self.w * 0.25))
        ty = self.h // 2 + random.randint(-int(self.h * 0.2), int(self.h * 0.2))

        # Build jagged segments
        num_segments = random.randint(6, 14)
        dx = (tx - ox) / num_segments
        dy = (ty - oy) / num_segments
        perp_x = -dy
        perp_y = dx
        length = math.hypot(perp_x, perp_y)
        if length > 0:
            perp_x /= length
            perp_y /= length

        points = [(ox, oy)]
        for i in range(1, num_segments):
            jag = random.uniform(-0.45, 0.45) * math.hypot(dx, dy) * 2.2
            px = ox + dx * i + perp_x * jag
            py = oy + dy * i + perp_y * jag
            points.append((px, py))
        points.append((tx, ty))

        # Random branches
        branches = []
        for i in range(1, len(points) - 1):
            if random.random() < 0.35:
                bx, by = points[i]
                branch_len = random.randint(3, 6)
                branch_angle = math.atan2(dy, dx) + random.uniform(-1.1, 1.1)
                bpoints = [(bx, by)]
                for _ in range(branch_len):
                    bx += math.cos(branch_angle) * random.uniform(8, 22)
                    by += math.sin(branch_angle) * random.uniform(8, 22)
                    branch_angle += random.uniform(-0.4, 0.4)
                    bpoints.append((bx, by))
                branches.append(bpoints)

        color_choice = random.choice([
            (200, 230, 255),   # cool white-blue
            (255, 255, 160),   # yellow-white
            (220, 180, 255),   # purple
            (160, 240, 255),   # cyan
        ])

        lifetime = random.uniform(0.06, 0.18)
        width = random.choice([1, 1, 2, 2, 3])

        self._lightning_bolts.append({
            "points": points,
            "branches": branches,
            "color": color_choice,
            "life": lifetime,
            "max_life": lifetime,
            "width": width,
            "flicker_phase": random.uniform(0, math.tau),
        })

    def draw_lightning(self) -> None:
        import math, random
        if not self._celebrate_active or self.screen is None:
            return

        CELEBRATE_DURATION = 3.0
        # Only fire lightning in first ~2.4s
        if self._celebrate_phase > 0.8:
            return

        dt_approx = 1.0 / TARGET_FPS

        # Spawn new bolts on timer
        self._lightning_timer -= dt_approx
        if self._lightning_timer <= 0:
            count = random.randint(1, 3)
            for _ in range(count):
                self._spawn_lightning_bolt()
            self._lightning_timer = random.uniform(0.14, 0.35)

        # Update and draw existing bolts
        alive = []
        for bolt in self._lightning_bolts:
            bolt["life"] -= dt_approx
            if bolt["life"] <= 0:
                continue
            alive.append(bolt)

            fade = bolt["life"] / bolt["max_life"]
            flicker = 0.7 + 0.3 * math.sin(bolt["flicker_phase"] + self._celebrate_phase * 40)
            alpha = int(255 * fade * flicker)
            alpha = max(0, min(255, alpha))

            r, g, b = bolt["color"]

            # Glow pass (wider, transparent)
            if len(bolt["points"]) >= 2:
                glow_surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
                glow_color = (r, g, b, max(0, alpha // 4))
                glow_w = bolt["width"] + 3
                for i in range(len(bolt["points"]) - 1):
                    p1 = (int(bolt["points"][i][0]), int(bolt["points"][i][1]))
                    p2 = (int(bolt["points"][i+1][0]), int(bolt["points"][i+1][1]))
                    pygame.draw.line(glow_surf, glow_color, p1, p2, glow_w)
                self.screen.blit(glow_surf, (0, 0))

                # Core bolt
                core_color = (
                    min(255, r + 60),
                    min(255, g + 60),
                    min(255, b + 60),
                    alpha,
                )
                core_surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
                for i in range(len(bolt["points"]) - 1):
                    p1 = (int(bolt["points"][i][0]), int(bolt["points"][i][1]))
                    p2 = (int(bolt["points"][i+1][0]), int(bolt["points"][i+1][1]))
                    pygame.draw.line(core_surf, core_color, p1, p2, bolt["width"])
                self.screen.blit(core_surf, (0, 0))

                # Branches (thinner, dimmer)
                for branch in bolt["branches"]:
                    if len(branch) < 2:
                        continue
                    branch_color = (r, g, b, max(0, alpha // 2))
                    branch_surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
                    for i in range(len(branch) - 1):
                        p1 = (int(branch[i][0]), int(branch[i][1]))
                        p2 = (int(branch[i+1][0]), int(branch[i+1][1]))
                        pygame.draw.line(branch_surf, branch_color, p1, p2, max(1, bolt["width"] - 1))
                    self.screen.blit(branch_surf, (0, 0))

        self._lightning_bolts = alive
    def _trigger_celebration(self) -> None:
        import math, random
        self._celebrate_active = True
        self._celebrate_phase = 0.0

        cx, cy = self.w // 2, self.h // 2 - int(self.h * 0.05)
        self._celebrate_particles = []

        for _ in range(36):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(90, 460)
            size = random.randint(2, 8)
            lifetime = random.uniform(0.7, 1.8)
            color_choice = random.choice([
                (255, 220, 60),
                (255, 245, 190),
                (120, 210, 255),
                (255, 255, 255),
            ])
            self._celebrate_particles.append({
                        "x": float(cx + random.uniform(-60, 60)),
                        "y": float(cy + random.uniform(-8, 8)),
                        "vx": math.cos(angle) * speed,
                        "vy": math.sin(angle) * speed,
                        "size": size,
                        "life": lifetime,
                        "max_life": lifetime,
                        "color": (255, 225, 90),
                    })

        self._lightning_bolts = []
        self._lightning_timer = 0.0
        self._lightning_spawn_interval = random.uniform(0.08, 0.18)

        for _ in range(12):
            angle = random.uniform(-2.2, -0.9)
            speed = random.uniform(140, 340)
            size = random.randint(3, 7)
            lifetime = random.uniform(0.8, 1.5)
            self._celebrate_particles.append({
                "x": float(cx + random.uniform(-60, 60)),
                "y": float(cy + random.uniform(-8, 8)),
                "vx": math.cos(angle) * speed,
                "vy": math.sin(angle) * speed,
                "size": size,
                "life": lifetime,
                "max_life": lifetime,
                "color": (255, 225, 90),
            })

        # Lightning bolts state
        self._lightning_bolts: list[dict] = []
        self._lightning_timer: float = 0.0
        self._lightning_spawn_interval: float = random.uniform(0.08, 0.18)

    def update_celebration(self, dt: float) -> None:
        if not self._celebrate_active:
            return

        CELEBRATE_DURATION = 3.0
        self._celebrate_phase += dt
        if self._celebrate_phase >= CELEBRATE_DURATION:
            self._celebrate_active = False
            self._celebrate_particles = []
            return

        gravity = 300.0
        for p in self._celebrate_particles:
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["vy"] += gravity * dt
            p["life"] -= dt

        self._celebrate_particles = [p for p in self._celebrate_particles if p["life"] > 0]

    def draw_celebration(self) -> None:
        import math
        if not self._celebrate_active or self.screen is None:
            return

        phase = self._celebrate_phase
        CELEBRATE_DURATION = 3.0

        if phase < 0.18:
            bloom_alpha = int(24 * (1.0 - phase / 0.18))
            bloom = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
            bloom.fill((180, 210, 255, bloom_alpha))
            self.screen.blit(bloom, (0, 0))
            
        # Softer celebration: no lightning during mission complete.
        cx_screen = self.w // 2
        cy_screen = self.h // 2 - int(self.h * 0.05)

        ring_t = min(1.0, phase / 0.45)
        if ring_t < 1.0:
            ring_radius = int(80 + ring_t * min(self.w, self.h) * 0.32)
            ring_alpha = int(140 * (1.0 - ring_t))
            ring_thickness = max(2, int(8 - 5 * ring_t))

            ring_surf = pygame.Surface((ring_radius * 2 + 20, ring_radius * 2 + 20), pygame.SRCALPHA)
            pygame.draw.circle(
                ring_surf,
                (255, 225, 120, ring_alpha),
                (ring_radius + 10, ring_radius + 10),
                ring_radius,
                ring_thickness,
            )
            self.screen.blit(ring_surf, (cx_screen - ring_radius - 10, cy_screen - ring_radius - 10))

        for p in self._celebrate_particles:
            fade = max(0.0, p["life"] / p["max_life"])
            r, g, b = p["color"]
            alpha = int(255 * fade)
            size = max(1, int(p["size"] * (0.4 + 0.6 * fade)))

            glow_size = max(2, int(size * 2.2))
            glow = pygame.Surface((glow_size * 2, glow_size * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow, (r, g, b, alpha // 5), (glow_size, glow_size), glow_size)
            self.screen.blit(glow, (int(p["x"]) - glow_size, int(p["y"]) - glow_size))

            surf = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
            pygame.draw.circle(surf, (r, g, b, alpha), (size, size), size)
            self.screen.blit(surf, (int(p["x"]) - size, int(p["y"]) - size))

        stamp_in = min(1.0, phase / 0.25)
        stamp_out = max(0.0, 1.0 - (phase - (CELEBRATE_DURATION - 0.55)) / 0.55)
        stamp_alpha = int(255 * min(stamp_in, stamp_out))

        if stamp_alpha > 0 and self.font is not None:
            try:
                stamp_font = pygame.font.SysFont(
                    "consolas",
                    max(18, int(38 * min(self.w / 1280, self.h / 720))),
                    bold=True,
                )
            except Exception:
                stamp_font = self.font

            scale_t = min(1.0, phase / 0.25)
            overshoot = 1.0 + 0.10 * math.sin(scale_t * math.pi)
            scale = max(0.01, scale_t * overshoot)

            base_text = "MISSION COMPLETE"
            text_surf = stamp_font.render(base_text, True, (235, 245, 255))

            tw = text_surf.get_width()
            th = text_surf.get_height()

            toast_w = tw + 68
            toast_h = th + 24

            enter_dur = 0.34
            hold_dur = 1.55
            exit_dur = 0.34

            tphase = self._toast_phase

            offscreen_x = self.w + 12
            onscreen_x = self.w - toast_w - 28

            if tphase < enter_dur:
                slide_t = tphase / enter_dur
                slide_t = 1.0 - (1.0 - slide_t) * (1.0 - slide_t)
                toast_x = int(offscreen_x + (onscreen_x - offscreen_x) * slide_t)

            elif tphase < enter_dur + hold_dur:
                toast_x = onscreen_x

            else:
                out_t = min(1.0, (tphase - enter_dur - hold_dur) / exit_dur)
                out_t = out_t * out_t
                toast_x = int(onscreen_x + (offscreen_x - onscreen_x) * out_t)

            toast_y = max(28, int(self.h * 0.10))

            toast = pygame.Surface((toast_w, toast_h), pygame.SRCALPHA)
            toast.fill((28, 30, 42, min(165, stamp_alpha)))

            pygame.draw.rect(
                toast,
                (255, 255, 255, min(26, stamp_alpha)),
                (2, 2, toast_w - 4, max(2, toast_h // 3)),
                border_radius=7,
            )

            pygame.draw.rect(
                toast,
                (255, 255, 255, min(10, stamp_alpha)),
                (0, 0, toast_w, toast_h),
                1,
                border_radius=7,
            )

            pygame.draw.rect(
                toast,
                (110, 145, 190, min(120, stamp_alpha)),
                (0, 0, toast_w, toast_h),
                1,
                border_radius=7,
            )

            pygame.draw.rect(
                toast,
                (255, 255, 255, min(34, stamp_alpha)),
                (3, 3, toast_w - 6, max(2, toast_h // 7)),
                border_radius=6,
            )

            pygame.draw.rect(
                toast,
                (115, 155, 235, min(150, stamp_alpha)),
                (8, 8, 4, toast_h - 16),
                border_radius=2,
            )

            toast.blit(text_surf, (34, 12))

            self.screen.blit(toast, (toast_x, toast_y))

    def update_mission_animations(self, dt: float) -> None:
        """Drive per-step metallic gradient animations each frame and fire celebration on final-step completion."""
        live_data = self.mission_overlay_data or {}
        holding = self._mission_hold_frames > 0
        data = self._mission_hold_data if holding else live_data

        steps = data.get("active_mission_steps") or []
        completed_count = int(data.get("completed_step_count", 0))
        current_idx = int(data.get("current_step_index", 0))

        ANIM_SPEED = 4.0

        for idx in range(len(steps)):
            t = self.step_anim.get(idx, None)
            if t is None:
                t = 1.0 if idx == current_idx else 0.0

            if idx < completed_count:
                t = max(0.0, t - dt * ANIM_SPEED)
            elif idx == current_idx:
                t = min(1.0, t + dt * ANIM_SPEED)
            else:
                t = max(0.0, t - dt * ANIM_SPEED)

            self.step_anim[idx] = t

        if holding:
            self._mission_hold_frames -= 1
            if self._mission_hold_frames <= 0:
                self._mission_hold_data = {}

        if completed_count > self._last_completed_for_bump:
            for done_idx in range(self._last_completed_for_bump, completed_count):
                self._row_bump[done_idx] = 1.0
        self._last_completed_for_bump = completed_count

        for bump_idx in list(self._row_bump):
            self._row_bump[bump_idx] = max(0.0, self._row_bump[bump_idx] - dt * 5.5)
            if self._row_bump[bump_idx] <= 0.0:
                del self._row_bump[bump_idx]

        if self._celebrate_active:
            self._toast_phase += dt
        else:
            self._toast_phase = 0.0

        live_steps = live_data.get("active_mission_steps") or []
        live_step_total = len(live_steps)
        live_completed_count = int(live_data.get("completed_step_count", 0))
        live_mission_id = str(live_data.get("active_mission_id") or "")
        celebrate_pending = bool(live_data.get("celebrate_pending", False))
        celebrate_token = int(live_data.get("celebrate_token", 0) or 0)

        should_celebrate = (
            celebrate_pending
            and celebrate_token > 0
            and celebrate_token != self._last_clear_seq_seen
        )

        if should_celebrate:
            held = dict(live_data)
            held["completed_step_count"] = max(live_completed_count, live_step_total)
            held["current_step_index"] = max(0, live_step_total - 1)

            self._mission_hold_data = held
            self._mission_hold_frames = self._mission_hold_duration_frames

            print(
                f"[celebrate fire] mission_id={live_mission_id} "
                f"celebrate_token={celebrate_token}"
            )

            self._toast_phase = 0.0
            self._trigger_celebration()
            self._last_clear_seq_seen = celebrate_token
            self._write_mission_celebrate_ack(celebrate_token)

        self._prev_live_mission_id = live_mission_id
        self._prev_live_completed_count = live_completed_count
        self._prev_live_step_total = live_step_total



    def draw_mission_overlay(self) -> None:
        self.mission_click_rects = []
        self.mission_panel_rect = None
        self.mission_toggle_rect = None
        self.mission_hint_rect = None

        if not self.mission_active or not self.mission_slot:
            return
        if self.screen is None or self.font is None or self.smallfont is None:
            return

        data = self._mission_hold_data if self._mission_hold_frames > 0 else (self.mission_overlay_data or {})
        character = data.get("character") or "Unknown"
        theme_color = self._char_theme_color(character)
        mission_name = data.get("active_mission_name") or "No mission loaded"
        mission_notes = data.get("active_mission_notes") or ""
        steps = data.get("active_mission_steps") or []
        missions = data.get("missions") or []
        goal_progress_type = data.get("goal_progress_type")
        goal_target_state = data.get("goal_target_state")
        goal_current_frames = int(data.get("goal_current_frames", 0) or 0)
        goal_needed_frames = int(data.get("goal_needed_frames", 0) or 0)
        goal_timer_active = bool(data.get("goal_timer_active", False))        

        selector_open = bool(data.get("selector_open", False))
        selector_index = int(data.get("selector_index", 0))
        selector_hint = data.get("selector_hint") or ""
        selector_controls = data.get("selector_controls") or ""

        title = self.font.render(
            f"{character} Mission Mode - {self.mission_slot}",
            True,
            (235, 235, 235),
        )

        completed_step_count = int(data.get("completed_step_count", 0))
        current_step_index = int(data.get("current_step_index", 0))
        progress_surf = self.smallfont.render(
            f"{completed_step_count}/{len(steps)}",
            True,
            (190, 200, 220),
        )

        pad = 10

        if selector_open:
            sub = self.smallfont.render("Mission Select", True, (180, 180, 180))
            ctrl = self.smallfont.render(selector_controls, True, (180, 180, 180))

            line_surfs = []
            for idx, mission in enumerate(missions):
                selected = idx == selector_index
                completed = bool(mission.get("completed", False))
                name = mission.get("name") or mission.get("mission_id") or f"Mission {idx + 1}"

                prefix = "->" if selected else "  "
                suffix = " [done]" if completed else ""
                color = (
                    (255, 220, 90)
                    if selected
                    else ((120, 220, 140) if completed else (220, 220, 220))
                )

                surf = self.smallfont.render(
                    f"{prefix} {idx + 1}. {name}{suffix}",
                    True,
                    color,
                )
                line_surfs.append((surf, mission.get("mission_id")))

            content_w = max(
                [title.get_width(), sub.get_width(), ctrl.get_width()]
                + [surf.get_width() for surf, _mission_id in line_surfs]
                + [260]
            )
            content_h = (
                title.get_height()
                + sub.get_height()
                + ctrl.get_height()
                + 12
                + sum(surf.get_height() + 6 for surf, _mission_id in line_surfs)
            )

            box_w = content_w + pad * 2
            box_h = content_h + pad * 2

            x = (self.w - box_w) // 2
            y = max(24, int(self.h * 0.08))
            self.mission_panel_rect = pygame.Rect(x, y, box_w, box_h)

            bg = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
            bg.fill((24, 16, 40, 210))

            scan_period = 2.2
            scan_t = (time.time() % scan_period) / scan_period
            scan_center_y = int(scan_t * (box_h + 40)) - 20

            for yy in range(box_h):
                dist = abs(yy - scan_center_y)

                if dist <= 2:
                    alpha = 70
                elif dist <= 6:
                    alpha = 38
                elif dist <= 12:
                    alpha = 18
                else:
                    alpha = 0

                if alpha > 0:
                    pygame.draw.line(
                        bg,
                        (theme_color[0], theme_color[1], theme_color[2], alpha),
                        (0, yy),
                        (box_w, yy),
                        1
                    )

            self.screen.blit(bg, (x, y))
            pygame.draw.rect(
                self.screen,
                theme_color,
                (x, y, box_w, box_h),
                1,
                border_radius=4,
            )

            pygame.draw.rect(
                self.screen,
                (255, 255, 255),
                (x + 2, y + 2, box_w - 4, box_h - 4),
                1,
                border_radius=4,
            )

            draw_y = y + pad
            self.screen.blit(title, (x + pad, draw_y))
            self.screen.blit(progress_surf, (x + box_w - pad - progress_surf.get_width(), draw_y + 2))
            draw_y += title.get_height() + 4
            self.screen.blit(sub, (x + pad, draw_y))
            draw_y += sub.get_height() + 4
            self.screen.blit(ctrl, (x + pad, draw_y))
            draw_y += ctrl.get_height() + 8

            for surf, mission_id in line_surfs:
                row_rect = pygame.Rect(
                    x + pad - 4,
                    draw_y - 2,
                    box_w - pad * 2 + 8,
                    surf.get_height() + 4,
                )
                self.mission_click_rects.append((row_rect, mission_id))

                if row_rect.collidepoint(pygame.mouse.get_pos()):
                    row_bg = pygame.Surface((row_rect.width, row_rect.height), pygame.SRCALPHA)
                    row_bg.fill((80, 60, 120, 120))
                    self.screen.blit(row_bg, (row_rect.x, row_rect.y))

                self.screen.blit(surf, (x + pad, draw_y))
                draw_y += surf.get_height() + 6

        else:
            sub = self.smallfont.render(mission_name, True, (180, 180, 180))
            hint = self.smallfont.render(selector_hint, True, (150, 150, 150))

            completed_step_count = int(data.get("completed_step_count", 0))
            current_step_index = int(data.get("current_step_index", 0))

            show_goal_timer = (
                goal_progress_type == "state_duration"
                and goal_target_state == "blockstun"
                and goal_needed_frames > 0
            )

            STEP_PAD_X = 8
            STEP_PAD_Y = 4
            STEP_GAP = 4
            STEP_VISIBLE_COUNT = 6

            max_start = max(0, len(steps) - STEP_VISIBLE_COUNT)
            if self.mission_show_all or len(steps) <= STEP_VISIBLE_COUNT:
                visible_start = 0
                visible_end = len(steps)
            else:
                visible_start = min(max(0, current_step_index - 2), max_start)
                visible_end = min(len(steps), visible_start + STEP_VISIBLE_COUNT)

            visible_steps = list(enumerate(steps[visible_start:visible_end], start=visible_start))

            toggle_text = "Show Less" if self.mission_show_all else "Show All"
            toggle_surf = self.smallfont.render(toggle_text, True, (220, 220, 220))
            hint_toggle_text = "Hide Hint" if self.mission_show_hint else "Show Hint"
            hint_toggle_surf = self.smallfont.render(hint_toggle_text, True, (220, 220, 220))

            panel_target_w = max(460, min(int(self.w * 0.15), 980))
            panel_inner_w = panel_target_w - pad * 2
            note_wrap_w = panel_inner_w - 12

            note_lines = (
                self._wrap_text_lines(mission_notes, self.smallfont, note_wrap_w)
                if mission_notes else []
            )
            note_line_surfs = [
                self.smallfont.render(line, True, (210, 210, 235))
                for line in note_lines
            ]

            # Build step surfaces to measure content width
            step_surfs = []
            for idx, step in visible_steps:
                if isinstance(step, dict):
                    step_text = str(step.get("display") or "").strip() or " / ".join(step.get("labels", []))
                elif isinstance(step, list):
                    step_text = " / ".join(step)
                else:
                    step_text = str(step)

                base_color = (180, 180, 180)

                if isinstance(step, dict):
                    c = step.get("color")
                    if c == "blue":
                        base_color = (115, 155, 235)   # softer steel blue
                    elif c == "yellow":
                        base_color = (220, 195, 105)   # muted gold
                    elif c == "green":
                        base_color = (105, 215, 155)   # jade mint

                if idx < completed_step_count:
                    label = f"[x] {idx + 1}. {step_text}"
                    color = base_color
                elif idx == current_step_index:
                    label = f"[>] {idx + 1}. {step_text}"
                    color = base_color
                else:
                    label = f"[ ] {idx + 1}. {step_text}"
                    color = base_color

                surf = self.smallfont.render(label, True, color)
                step_surfs.append((idx, surf, color))

            step_row_h = (step_surfs[0][1].get_height() if step_surfs else 18) + STEP_PAD_Y * 2

            timer_block_h = 0
            if show_goal_timer:
                timer_block_h = 44

            content_h = (
                title.get_height()
                + sub.get_height()
                + hint.get_height()
                + 16
                + timer_block_h
                + ((sum(surf.get_height() for surf in note_line_surfs) + 16) if (self.mission_show_hint and note_line_surfs) else 0)
                + len(step_surfs) * (step_row_h + STEP_GAP)
            )

            box_w = panel_target_w
            box_h = content_h + pad * 2

            x = (self.w - box_w) // 2
            y = max(24, int(self.h * 0.08))
            self.mission_panel_rect = pygame.Rect(x, y, box_w, box_h)

            # Outer panel
            bg = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
            bg.fill((24, 16, 40, 210))

            scan_period = 2.2
            scan_t = (time.time() % scan_period) / scan_period
            scan_center_y = int(scan_t * (box_h + 40)) - 20

            for yy in range(box_h):
                dist = abs(yy - scan_center_y)

                if dist <= 2:
                    alpha = 70
                elif dist <= 6:
                    alpha = 38
                elif dist <= 12:
                    alpha = 18
                else:
                    alpha = 0

                if alpha > 0:
                    pygame.draw.line(
                        bg,
                        (theme_color[0], theme_color[1], theme_color[2], alpha),
                        (0, yy),
                        (box_w, yy),
                        1
                    )

            diag_t = (time.time() * 48.0) % (box_w + box_h)
            for i in range(2):
                dx = int(diag_t - box_h - i * 90)
                pygame.draw.line(
                    bg,
                    (theme_color[0], theme_color[1], theme_color[2], 18),
                    (dx, box_h),
                    (dx + box_h, 0),
                    1,
                )

            self.screen.blit(bg, (x, y))
            pygame.draw.rect(
                self.screen,
                (170, 120, 255),
                (x, y, box_w, box_h),
                1,
                border_radius=4,
            )

            draw_y = y + pad
            self.screen.blit(title, (x + pad, draw_y))
            self.screen.blit(progress_surf, (x + box_w - pad - progress_surf.get_width(), draw_y + 2))
            draw_y += title.get_height() + 4

            progress_frac = 0.0 if len(steps) <= 0 else max(0.0, min(1.0, completed_step_count / float(len(steps))))
            progress_x = x + pad
            progress_y = draw_y
            progress_w = box_w - pad * 2
            pygame.draw.rect(self.screen, (38, 34, 58), (progress_x, progress_y, progress_w, 3), border_radius=2)
            if progress_w > 0 and progress_frac > 0.0:
                pygame.draw.rect(
                    self.screen,
                    theme_color,
                    (progress_x, progress_y, int(progress_w * progress_frac), 3),
                    border_radius=2,
                )

            draw_y += 7
            self.screen.blit(sub, (x + pad, draw_y))
            draw_y += sub.get_height() + 4
            self.screen.blit(hint, (x + pad, draw_y))

            header_divider_y = draw_y + hint.get_height() + 6
            pygame.draw.line(
                self.screen,
                (70, 62, 100),
                (x + pad, header_divider_y),
                (x + box_w - pad, header_divider_y),
                1,
            )

            toggle_w = toggle_surf.get_width() + 14
            toggle_h = toggle_surf.get_height() + 6
            hint_toggle_w = hint_toggle_surf.get_width() + 14
            hint_toggle_h = hint_toggle_surf.get_height() + 6

            hint_toggle_x = x + box_w - pad - hint_toggle_w
            toggle_x = hint_toggle_x - 8 - toggle_w
            toggle_y = draw_y - 2

            self.mission_toggle_rect = pygame.Rect(toggle_x, toggle_y, toggle_w, toggle_h)
            self.mission_hint_rect = pygame.Rect(hint_toggle_x, toggle_y, hint_toggle_w, hint_toggle_h)

            toggle_col = (70, 70, 95) if not self.mission_show_all else (110, 80, 150)
            if self.mission_toggle_rect.collidepoint(pygame.mouse.get_pos()):
                toggle_col = tuple(min(255, c + 25) for c in toggle_col)

            hint_col = (70, 70, 95) if not self.mission_show_hint else (110, 80, 150)
            if self.mission_hint_rect.collidepoint(pygame.mouse.get_pos()):
                hint_col = tuple(min(255, c + 25) for c in hint_col)

            pygame.draw.rect(self.screen, toggle_col, self.mission_toggle_rect, border_radius=3)
            pygame.draw.rect(self.screen, (180, 180, 200), self.mission_toggle_rect, 1, border_radius=3)
            self.screen.blit(toggle_surf, (toggle_x + 7, toggle_y + 3))

            pygame.draw.rect(self.screen, hint_col, self.mission_hint_rect, border_radius=3)
            pygame.draw.rect(self.screen, (180, 180, 200), self.mission_hint_rect, 1, border_radius=3)
            self.screen.blit(hint_toggle_surf, (hint_toggle_x + 7, toggle_y + 3))

            draw_y += hint.get_height() + 12
            if show_goal_timer:
                timer_rect = pygame.Rect(x + pad, draw_y, box_w - pad * 2, 36)

                timer_bg = pygame.Surface((timer_rect.width, timer_rect.height), pygame.SRCALPHA)
                timer_bg.fill((30, 24, 50, 220))
                self.screen.blit(timer_bg, (timer_rect.x, timer_rect.y))
                pygame.draw.rect(self.screen, (120, 110, 170), timer_rect, 1, border_radius=3)

                fill_frac = 0.0
                if goal_needed_frames > 0:
                    fill_frac = max(0.0, min(1.0, goal_current_frames / float(goal_needed_frames)))

                inner_pad = 6
                bar_x = timer_rect.x + inner_pad
                bar_y = timer_rect.y + 18
                bar_w = timer_rect.width - inner_pad * 2
                bar_h = 10

                pygame.draw.rect(
                    self.screen,
                    (46, 40, 70),
                    (bar_x, bar_y, bar_w, bar_h),
                    border_radius=3,
                )

                fill_w = int(bar_w * fill_frac)
                fill_color = (90, 210, 255) if goal_timer_active else (110, 140, 170)

                if fill_w > 0:
                    pygame.draw.rect(
                        self.screen,
                        fill_color,
                        (bar_x, bar_y, fill_w, bar_h),
                        border_radius=3,
                    )

                timer_label = self.smallfont.render(
                    f"Blockstun Timer: {goal_current_frames}/{goal_needed_frames}f",
                    True,
                    (235, 235, 245) if goal_timer_active else (180, 180, 190),
                )
                self.screen.blit(timer_label, (timer_rect.x + inner_pad, timer_rect.y + 3))

                draw_y += timer_rect.height + 8

            if self.mission_show_hint and note_line_surfs:
                note_h = sum(surf.get_height() for surf in note_line_surfs) + 16
                note_rect = pygame.Rect(x + pad, draw_y, box_w - pad * 2, note_h)
                note_bg = pygame.Surface((note_rect.width, note_rect.height), pygame.SRCALPHA)
                note_bg.fill((36, 28, 56, 210))
                self.screen.blit(note_bg, (note_rect.x, note_rect.y))
                pygame.draw.rect(self.screen, (120, 110, 170), note_rect, 1, border_radius=3)

                note_y = note_rect.y + 6
                for surf in note_line_surfs:
                    self.screen.blit(surf, (note_rect.x + 6, note_y))
                    note_y += surf.get_height()

                draw_y += note_rect.height + 8

            # Step boxes
            step_box_w = box_w - pad * 2
            for idx, surf, text_color in step_surfs:
                t = self.step_anim.get(idx, 0.0)
                is_completed = idx < completed_step_count
                is_active = idx == current_step_index

                # --- background box ---
                row_surf = pygame.Surface((step_box_w, step_row_h), pygame.SRCALPHA)
                pulse = 0.5 + 0.5 * __import__("math").sin(time.time() * 6.0)

                if is_completed:
                    # Dark, slightly greenish, no gradient
                    alpha = int(180 - t * 60)  # fades as t drops to 0
                    row_surf.fill((20, 38, 26, alpha))
                    border_color = (60, 140, 80, int(80 + t * 100))
                elif is_active and t > 0.0:
                    # Metallic blue gradient — drawn as horizontal strips
                    for strip_y in range(step_row_h):
                        frac = strip_y / max(step_row_h - 1, 1)
                        # gradient: dark blue at top/bottom, brighter mid
                        mid = 1.0 - abs(frac - 0.45) * 2.2
                        mid = max(0.0, min(1.0, mid))

                        base_r = int(18 + mid * 20)
                        base_g = int(60 + mid * 60)
                        base_b = int(110 + mid * 100)

                        # Blend toward dark base as t approaches 0
                        dark_r, dark_g, dark_b = 28, 22, 44
                        r = int(dark_r + (base_r - dark_r) * t)
                        g = int(dark_g + (base_g - dark_g) * t)
                        b = int(dark_b + (base_b - dark_b) * t)

                        pygame.draw.line(row_surf, (r, g, b, 210), (0, strip_y), (step_box_w, strip_y))

                        border_color = (
                            min(255, int(theme_color[0] + 50 * pulse)),
                            min(255, int(theme_color[1] + 50 * pulse)),
                            min(255, int(theme_color[2] + 50 * pulse)),
                            220,
                        )

                else:
                    # Pending or animating out — dark base
                    row_surf.fill((28, 22, 44, 180))
                    border_color = (80, 70, 110, 120)

                bump = self._row_bump.get(idx, 0.0)
                row_offset_x = int(3 * bump)

                self.screen.blit(row_surf, (x + pad + row_offset_x, draw_y))

                pygame.draw.rect(
                    self.screen,
                    text_color,
                    (x + pad + 3 + row_offset_x, draw_y + 3, 4, step_row_h - 6),
                    border_radius=2,
                )

                if is_completed:
                    sweep_t = self.step_anim.get(idx, 0.0)
                    if sweep_t > 0.05:
                        sweep_x = int((1.0 - sweep_t) * step_box_w)
                        sweep = pygame.Surface((36, step_row_h), pygame.SRCALPHA)
                        sweep.fill((255, 255, 255, int(70 * sweep_t)))
                        self.screen.blit(sweep, (x + pad + row_offset_x + sweep_x, draw_y))

                pygame.draw.rect(
                    self.screen,
                    border_color[:3],
                    (x + pad + row_offset_x, draw_y, step_box_w, step_row_h),
                    1,
                    border_radius=3,
                )

                # Text — dim completed steps based on animation
                step = steps[idx]
                if isinstance(step, dict):
                    step_text = str(step.get("display") or "").strip() or " / ".join(step.get("labels", []))
                elif isinstance(step, list):
                    step_text = " / ".join(step)
                else:
                    step_text = str(step)
                if is_completed:
                    label_str = f"[x] {idx + 1}. {step_text}"
                elif is_active:
                    caret_on = int(time.time() * 4.0) % 2 == 0
                    label_str = f"[{'>' if caret_on else ' '} ] {idx + 1}. {step_text}"
                else:
                    label_str = f"[ ] {idx + 1}. {step_text}"
                if is_completed:
                    draw_color = (165, 165, 175)
                elif is_active:
                    draw_color = (235, 245, 255)
                else:
                    draw_color = text_color

                shadow = self.smallfont.render(label_str, True, (18, 18, 24))
                self.screen.blit(shadow, (x + pad + STEP_PAD_X + 1 + row_offset_x, draw_y + STEP_PAD_Y + 1))

                draw_surf = self.smallfont.render(label_str, True, draw_color)

                self.screen.blit(draw_surf, (x + pad + STEP_PAD_X + row_offset_x, draw_y + STEP_PAD_Y))
                draw_y += step_row_h + STEP_GAP

            if not self.mission_show_all and len(steps) > STEP_VISIBLE_COUNT:
                footer = self.smallfont.render(
                    f"Showing {visible_start + 1}-{visible_end} of {len(steps)}",
                    True,
                    (140, 140, 160),
                )
                self.screen.blit(footer, (x + pad, draw_y + 2))


    def present(self) -> None:
        pygame.display.flip()

    def run(self) -> None:
        self.init()
        assert self.clock is not None
        assert self.screen is not None
        assert self.dolphin_hwnd is not None
        assert self.overlay_hwnd is not None

        print("[master] started")
        print("[master] overlay controls are managed by the main GUI")

        while self.running:
            try:
                sync_size = sync_overlay_to_dolphin(self.dolphin_hwnd, self.overlay_hwnd)
                if sync_size is None:
                    self.dolphin_hwnd = find_dolphin_hwnd()
                    sync_size = sync_overlay_to_dolphin(self.dolphin_hwnd, self.overlay_hwnd)

                if sync_size is None:
                    self.handle_events()
                    self.clock.tick(TARGET_FPS)
                    continue

                w, h = sync_size
                self.on_resize(w, h)

                self._read_control_file()
                self._read_mission_mode_file()
                self._read_mission_overlay_file()
                self.handle_events()

                dt = self.clock.tick(TARGET_FPS) / 1000.0

                self.clear()

                try:
                    self.hitbox_renderer.update(dt, self.control)
                except Exception as exc:
                    print("[master] hitbox update failed")
                    traceback.print_exc()
                    self.hitbox_renderer = NullHitboxRenderer()
                    self.hitbox_renderer.on_resize(self.w, self.h)

                try:
                    self.hud_renderer.update(dt, self.control)
                except Exception as exc:
                    print("[master] hud update failed")
                    traceback.print_exc()
                    self.hud_renderer = NullHudRenderer()
                    self.hud_renderer.on_resize(self.w, self.h)

                self.update_mission_animations(dt)
                self.update_celebration(dt)

                try:
                    self.hitbox_renderer.draw(self.screen, self.control)
                except Exception as exc:
                    print("[master] hitbox draw failed")
                    traceback.print_exc()
                    self.hitbox_renderer = NullHitboxRenderer()
                    self.hitbox_renderer.on_resize(self.w, self.h)

                try:
                    self.hud_renderer.draw(self.screen, self.control)
                except Exception as exc:
                    print("[master] hud draw failed")
                    traceback.print_exc()
                    self.hud_renderer = NullHudRenderer()
                    self.hud_renderer.on_resize(self.w, self.h)

                self.draw_mission_overlay()
                self.draw_celebration()
                self.draw_master_debug(dt)

                self.present()

            except Exception as exc:
                pause_on_error("MasterLoopCrash", exc)
                self.running = False

        pygame.quit()


def main() -> None:
    overlay = MasterOverlay()
    overlay.run()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        pause_on_error("FatalCrash", exc)
        raise